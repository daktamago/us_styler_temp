// ============================================================================
//  styleus.h  --  REPAIRED COPY
// ----------------------------------------------------------------------------
//  원본 C:\Working\Medical\dll_simul\styleus.h 는 붙여넣기 과정에서 토큰 사이의
//  단일 공백이 소실되어 컴파일 불가 상태다.
//      원본 3행 : #ifdefSTYLEUS_EXPORTS
//      원본 4행 : #defineSTYLEUS_API__declspec(dllexport)
//      원본 26행: STYLEUS_API voidRunStyleUSInference(
//      원본 28행: constchar* styleName
//  이 파일은 공백만 복원한 것이며, 선언 내용은 원본과 100% 동일하다.
//  사내 원본 헤더를 다시 확보하면 이 파일을 폐기하고 그것으로 교체할 것.
// ============================================================================

#ifdef STYLEUS_EXPORTS
#define STYLEUS_API __declspec(dllexport)
#else
#define STYLEUS_API __declspec(dllimport)
#endif

extern "C" {

/**
 * @brief Input format identifier for StyleUS DLL
 */
enum class StyleUSInputFormat {
    RAW = 0,    // Direct raw beamformed polar data
    DICOM = 1   // Scan-converted diagnostic DICOM screen data
};

/**
 * @brief Executes the AI Style Transfer pipeline, saves result parameters, and exits.
 *        No return pointers are needed. The process blocks the caller until files are safely written.
 *
 * @param inputFormat   : Specifies whether to load raw or scan-converted DICOM data (0: RAW, 1: DICOM)
 * @param styleName     : Name of the style preset to search and load (e.g., "style01", "style02")
 */
STYLEUS_API void RunStyleUSInference(
    StyleUSInputFormat inputFormat,
    const char* styleName
);

/**
 * @brief Forces immediate termination/cleanup of ongoing inference tasks when live mode is activated
 */
STYLEUS_API void ForceExitStyleUS();

}
