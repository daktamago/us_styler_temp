// ============================================================================
//  SDMR/DllMain.h  --  REPAIRED COPY
// ----------------------------------------------------------------------------
//  원본 C:\Working\Medical\dll_simul\SDMR\DllMain.h 는 붙여넣기 과정에서 토큰
//  사이의 단일 공백이 34곳 소실되어 컴파일 불가 상태다.
//      예) #pragmaonce / #include"CommonDef.h" / typedefstructRSDMR
//          voidRSDMRtoSDMR(RSDMR*stRSDMR, intiWidth, ...)
//  이 파일은 공백만 복원한 것이며 필드 순서/타입/개수는 원본과 100% 동일하다.
//  사내 원본을 다시 확보하면 이 파일을 폐기하고 그것으로 교체할 것.
//
//  [검증] 전 멤버가 4바이트 크기/4바이트 정렬이므로 패딩이 발생하지 않는다.
//         sizeof(RSDMR) = 12 + 24*2 + 52*2 + 16 + 20 + 56 = 256
//         => style_result.rsdmr = 8 + 256*5 = 1288 bytes
//         styleus_shim.cpp 에서 static_assert 로 강제 확인한다.
// ============================================================================

#ifndef HEADER_FILE_ID
#define HEADER_FILE_ID    _DLLMAIN_H_
#endif /* HEADER_FILE_ID */


#pragma once

#include "CommonDef.h"
#include "SLibUtils.h"  ///< for exception & trace file

#ifdef SMIS_APP
#define SMIS_DLL_API __declspec(dllimport)
#else
#define SMIS_DLL_API __declspec(dllexport)
#endif


//#define ReleaseVer      1
#define ReleaseVer1_03 1

/*
 * @struct    _ScanConvDataInfo
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     dmr File Parameter Structure for Probe Geometry
 */
typedef struct ScanConvDataInfo
{
    int     nScanType;      /* 0:Linear, 1:Convex */
    int     nBitPerData;
    int     nDataType;      /* 0:BW */
    int     nSteeringType;
    int     nSampleNum;
    int     nScanlineNum;
    int     nSampleMax;
    int     nScanlineMax;
    int     nStartSample;
    int     nSampleMem;
    int     nStartScanline;
    int     nEndScanline;
    float   fSamplePerMM;
    float   fSampleDensity;
    float   fScanlinePerAngle;
    float   fScanStartAngle;
    float   fScanStartOffset;
    float   fSamplePerPixel;
    float   fFramePerSec;
    float   fSteeringAngle;
    int     nScan_researved[128 - 20];    /* MAX 128 : 512 Byte */
} STDATAINFO;


/*
 * @struct    _DMRHeaderInfo
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     dmr Header Information
 */
typedef struct DMRHeaderInfo
{
    int        frameNum;
    float      txFreq;
    STDATAINFO stdmr;
} DMRINFO;


/*
 * @struct    _LVPARAMUSDLL
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     File Parameter Structure for dll module (Level)
 */
typedef struct LvPARAMUSDLL
{
    /* -- US EdgeMap Parameter */
    int   iInfoBias;         /* < [ for Get Information ] _LVPARAMUS::iBias */
    float fInfoThreshold;    /* < [ for Get Information ] _LVPARAMUS::fThreshold */
    float fInfoEdWeight;     /* < [ for Get Information ] _LVPARAMUS::fEdWeight */
    float fInfoEiWeight;     /* < [ for Get Information ] _LVPARAMUS::fEiWeight */

    /* -- US Diffusion Filtering Parameter */
    int   iDifIteration;     /* < [ for Diffusion filter ] _LVPARAMUS::iDifIteration */
    int   iDifStep;          /* < [ for Diffusion filter ] _LVPARAMUS::iDifStep*/
    int   iDifCoherence;     /* < [ for Diffusion filter ] _LVPARAMUS::iDifCoherence */
    int   iDifSmooth;        /* < [ for Diffusion filter ] _LVPARAMUS::iSmooth */
    int   iDifEnhance;       /* < [ for Diffusion filter ] _LVPARAMUS::iEnhance */

    /* -- US Laplacian Gain Parameter */
    int   iLapGainDark;      /* < [ for Laplacian Gain ] _LVPARAMUS::iLapGainDark */
    int   iLapGainBright;    /* < [ for Laplacian Gain ] _LVPARAMUS::iLapGainBright */
    int   iLapGainEdge;      /* < [ for Laplacian Gain ] _LVPARAMUS::iLapGainEdge */
    int   iLapAvgEdge;       /* < [ for Laplacian Gain ] _LvParamUS::iLapSmoothEdge */
    int   iLapNMenable;      /* < [ for Nonlinear mapping] _LVPARAMUS::iNMen */
    int   iLapNMcurve;       /* < [ for Nonlinear mapping] _LVPARAMUS::iNMcurve */
    int   iLapNMlimit;       /* < [ for Nonlinear mapping] _LVPARAMUS::iNMlimit */
    float fLapNMgain;        /* < [ for Nonlinear mapping] _LVPARAMUS::fNMgain */
    float fLapShirinkage;    // for Laplacian shrinkage               //2014.1.28

    /* -- US Directional Filtering Parameters */
    int   iDirPosition;      /* [ for Directional filter ] _LVPARAMUS::iDirPosition */
    int   iDirIteration;     /* < [ for Directional filter ] _LVPARAMUS::iDirIteration */
    int   iDirSmthEdge;      /* < [ for Directional filter ] _LVPARAMUS::iDirSmthEdge */
    int   iDirSmthNonEdge;   /* < [ for Directional filter ] _LVPARAMUS::iDirSmthNonEdge */
    int   iDirShrpEdge;      /* < [ for Directional filter ] _LVPARAMUS::iDirShrpEdge */
    int   iDirShrpNonEdge;   /* < [ for Directional filter ] _LVPARAMUS::iDirShrpNonEdge */
    float fDirPosLimitRate;  /// Directional change rate - positive
    float fDirNegLimitRate;  /// Directional change rate - negative
    int   iDirLimitationType;                             //2014.1.28
    float fFeatureAmplitude;

    /*-- US Geometry parameter */
    int   iGeoEnable;        /* < [ for Probe Geometry ] _LVPARAMUS::iEnGeo */
    float fGeoScaleMin;      /* < [ for Probe Geometry ] _LVPARAMUS::fScaleMin */
    float fGeoScaleMax;      /* < [ for Probe Geometry ] _LVPARAMUS::fScaleMax */
    float fGeoSquareRate;    /* < [ for Probe Geometry ] _LVPARAMUS::fRate */

    /* -- Transform Parameter */
    int   iTransdecW;        /* < [ for Transform ] _LVPARAMUS::idecW */
    int   iTransdecH;        /* < [ for Transform ] _LVPARAMUS::idecH */
} LVPARAMUSDLL;

/*
 * @struct    _GLOBPARAMUSDLL
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     File Parameter Structure for dll module (Global)
 */
typedef struct GlobPARAMUSDLL
{
    int iFlagNewSDMR;
    //-- mode & option
    ///- <b>[Bit fields]</b>
    /// @image html iMode.png
    int   iMode;                /* < Operation mode select */
    ///- <b>[Bit fields]</b>
    /// @image html iOption.png
    ///.
    /// \n<b>[Example]</b>
    ///- 0: None\n
    ///- 1: Diffusion filter\n
    ///- 2: Directional filter\n
    ///- 3: Diffusion + Directional filter\n
    ///- 4: Generate Log files
    ///- 5: Generate Log files with Diffusion filter
    ///- 6: Generate Log files with Directional filter
    ///- 7: Generate Log files with Diffusion + Directional filter
    ///.
    int   iOption;             /* < Function enable Option */
    /* -- raw file information */
    int   iWidth;              /* < Image width */
    int   iHeight;             /* < Image height */

    /* -- Laplacian Pyramid Parameters */
    int   iLevel;              /* < Laplacian Pyramid Levels (Max=8) */
    int   iGauSize;            /* < 1: Gaussian Filter 5X5, 2: 3X3 */
    int   iTCenable;           /* < Temporal compounding enable */
    int   iTClevel;            /* < Temporal compounding level */
    int   iTCBLKWidth;         /* < Temporal compounding block width */
    int   iTCBLKHeight;        /* < Temporal compounding block height */
    int   iTCswW;              /* < Temporal compounding search window width */
    int   iTCswH;              /* < Temporal compounding search window height */
    int   iTCoverlap;          /* < Temporal compounding compensate overlap length */
    int   iTCadaptWeightEn;    /* < Temporal compounding adaptive IIR weight enable */
    int   iTCweightMin;        /* < Temporal compounding minimum weight */
    int   iTCweightMax;        /* < Temporal compounding minimum weight */
    int   iTCtrueMVEn;         /* < Temporal compounding true mv refinement enable */
    int   iTCtrueMVStage;      /* < Temporal compounding true mv stage (1:all 1, 3:weighted median) */

    /*-- Sharpening filter Parameters */
    int   iSPlevel;            /* < Sharpening filter level */
    float fSPgainMax;          /* < Sharpening filter Maximum gain */
    float fSPgain;             /* < Sharpening filter gain (0~1 => 0~fSPgainMax) */

    /* -- Zoom */
    int   iZCen;
    float fZCBaseMM;
    float fZCgain;

    /* -- Edge Thinning */
    float fEdgeThinning;

    /*-- Decimation Type for Level 1 --*/
    int   iDecimationType_Lv1;

    /*-- Vector merge  --*/
    float fVectorMerge;

    /*-- Contrast Curve --*/
    float fContrastCurveLowSlope;
    float fContrastCurveLowPivot;
    float fContrastCurveHighSlope;
    float fContrastCurveHighPivot;
    ///*-- Edge Margin Enhancement --*/
    int   iAdaptiveEdgeSmooth;        // 2018.04.02 jg0228.park
    int   iAdaptiveEdgeContrast;      // 2018.04.02 jg0228.park
    int   iHaloStrength;              // 2018.04.02 jg0228.park
    int   iEdgeStrength;              // 2018.04.02 jg0228.park
    // connectivity related parameter
    int   iConnectivity;       // 2020.05.25 huisu.yoon
    int   iterPreMid;          // 2020.05.25 huisu.yoon
} GLOBPARAMUSDLL;


/*
 * @struct    _PARAMUSDLL
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     File Parameter Structure for dll module
 */
typedef struct ParamUSDll
{
    /* -- level independent parameter -- include Temporal Compounding */
    GLOBPARAMUSDLL  stGlobUsParam;          /* < Global Parameters */
    /* -- level dependent parameter -- diffusion/directional filtering */
    LVPARAMUSDLL    stLvUsParam[MAX_LEVEL]; /* < LVPARAMUSDLL Sets */

    int researved[16];
} PARAMUSDLL;

#ifndef __SDMR_STRUCT_DEFINE__
#define __SDMR_STRUCT_DEFINE__
/*
 * @struct    _RSDMR_Pattern
 * @author    Legacy, Lee Dongseok (daniel86.lee) )
 * @date      Legacy, 2013.04.16
 * @brief     Input Pattern Parameter Structure
 */
typedef struct RSDMR_Pattern
{
    int iNRCurveThreshold;
    int iNRCurveStrength;
    int iLapGainDarkArea;
    int iLapGainBrightArea;
    int iReserved[2];
} RSDMR_P;

/*
 * @struct    _RSDMR_Shape
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     Input Shape Parameter Structure
 */
typedef struct RSDMR_Shape
{
    float fEdgeThreshold;
    int   iNRStrength;
    int   iEdgeSmooth;
    int   iEdgeContrast;
    int   iNonEdgeSmooth;
    int   iNonEdgeContrast;
    int   iDirPosition;
    int   iLapGainDarkArea;
    int   iLapGainBrightArea;
    int   iLapSmoothRate;
    int   iLapAverageRate;
    float fDirPosLimitRate;
    float fDirNegLimitRate;
    //int   iReserved[2];
} RSDMR_S;

/*
 * @struct    _RSDMR_Motion
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     Input Motion Parameter Structure
 */
typedef struct RSDMR_Motion
{
    int   iMotionProcPosition;
    int   iMotionStableGain;
    int   iReserved[2];
} RSDMR_M;

/*
 * @struct    _RSDMR_Zoom
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     Input Zoom Parameter Structure
 */
typedef struct RSDMR_Zoom
{
    int   iZoomEnable;
    float fZoomBaseResolution;
    float fZoomEffectGain;
    int   ContrastCurve;
    int   iReserved;
} RSDMR_Z;

/*
 * @struct    _RSDMR
 * @author    Legacy, Lee Dongseok (daniel86.lee)
 * @date      Legacy, 2013.04.16
 * @brief     Input Parameter Structure
 */
typedef struct RSDMR
{
    int   iNumPyrLevel;     // 1
    float fSharpGain;       // 1
    float fEdgeThinning;    // 1
    RSDMR_P p0;             // 6
    RSDMR_P p1;             // 6
    RSDMR_S s0;             // 13
    RSDMR_S s1;             // 13
    RSDMR_M motion;         // 4
    RSDMR_Z zoom;           // 5
    int   iGeometryCase;    // 1
    float fVectorMerge;         //For building gaps between Spine bones
    int   iEdgeSmooth_Lv1;      //L1 Dir
    int   iEdgeContrast_Lv1;    //L1 Dir
    int   iNonEdgeSmooth_Lv1;   //L1 Dir
    int   iNonEdgeContrast_Lv1; //L1 Dir
    int   iDirPosition_Lv1;     // "IMT" for Gabor vector
    float fDirPosLimitRate_Lv1; //L1 Dir
    float fDirNegLimitRate_Lv1; //L1 Dir
    int   iDirLimitationType;
    int   iDecimationType_Lv1;  // 1:1/2  or 1/2:1/2
    int   iLapShrinkage;        // (L0, L1, L2)
    int   iFeatureAmplitude;    // (L1, L2, L3)
    float fEdgeThreshold_Lv1;   //Edge map Threshold for Lv1
} RSDMR;


typedef struct Flag
{
    int FlagNewSDMR;
    int FlagBCDMode;
    int FlagSCI;
} Flag;

#endif

void RSDMRtoSDMR(RSDMR* stRSDMR, int iWidth, int iHeight, Flag* pstFlag, PARAMUSDLL* stSDMR);
void SDMR_Fixed(PARAMUSDLL* stSDMR);
void SDMR_Structure(int iNumPyrLevel, PARAMUSDLL* stSDMR);
void SDMR_NonlinearMapping(RSDMR_P P, LVPARAMUSDLL* stLvParam);
void SDMR_Diffusion(int iDifStr, LVPARAMUSDLL* stLvParam);
void SDMR_Directional(RSDMR_S S, LVPARAMUSDLL* stLvParam);
void SDMR_Geometry(int iCase, LVPARAMUSDLL* stLvParam);
void SDMR_Temporal(RSDMR_M M, GLOBPARAMUSDLL* stGlobParam);
void SDMR_DMRPlus_features(RSDMR* stRSDMR, PARAMUSDLL* stSDMR);
void SDMR_Contrast_Curve(RSDMR* stRSDMR, PARAMUSDLL* stSDMR);
void SDMR_SetParam(void* hHandle, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int& isTPon, Flag* pstFlag);
void SDMR_MainProcess(void* hHandle, int isTPon, Flag* pstFlag, int shortFlag);
void ippiCopy_16s_C1R_normal(const short* pSrc, int srcStep, short* pDst, int dstStep, int width, int height);
void ippiCopy_16s_C1R_normal(const unsigned char* pSrc, int srcStep, short* pDst, int dstStep, int width, int height);
void ippiCopy_16s_C1R_normal(const short* pSrc, int srcStep, unsigned char* pDst, int dstStep, int width, int height);
void ippiConvert_8u16s_C1R_normal(const unsigned char* src, int src_step, short* dst, int dst_step, int width, int height);
void ippiConvert_16s8u_C1R_normal(short* src, int src_step, unsigned char* dst, int dst_step, int width, int height);

extern "C"
{
    SMIS_DLL_API void* CreateSDMR();
    SMIS_DLL_API void  DestroySDMR(void* hHandle);

#ifdef ReleaseVer1_03
    SMIS_DLL_API void SDMRProcess(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon, Flag* pstFlag);
    SMIS_DLL_API void SDMRProcessPost(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, unsigned char* pDataMask, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon, Flag* pstFlag);
    SMIS_DLL_API void SDMRProcessShort(void* hHandle, short* pDataIn, short* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon, Flag* pstFlag);
    SMIS_DLL_API void SDMRProcessShortBWProc(void* hHandle, short* pDataIn, short* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon, Flag* pstFlag);
#elif ReleaseVer
    SMIS_DLL_API void SDMRProcess(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon);
    SMIS_DLL_API void SDMRProcessPost(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, unsigned char* pDataMask, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon, Flag* pstFlag);
    SMIS_DLL_API void SDMRProcessShort(void* hHandle, short* pDataIn, short* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon);
#else
    SMIS_DLL_API void SDMRProcess(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon);
    SMIS_DLL_API void SDMRProcessPost(void* hHandle, unsigned char* pDataIn, unsigned char* pDataOut, unsigned char* pDataMask, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon);
    SMIS_DLL_API void SDMRProcessShort(void* hHandle, short* pDataIn, short* pDataOut, RSDMR* pRSDMRPARAM, STDATAINFO* pGEOPARAM, int displayMode, int* option, bool* pIsCX2ParamChanged, int isTPon);
#endif

    //SMIS_DLL_API void setUSparam(ParamUSDll* pstParam);
    //SMIS_DLL_API void setDMRparam(DMRINFO* pstParam);
    //SMIS_DLL_API void createUSprocess(short* pDataIn, short* pDataOut);
    //SMIS_DLL_API void runUSprocess(short* pDataIn, short* pDataOut);
    //SMIS_DLL_API void destroyUSprocess();
}
