// ============================================================================
//  sim_dump.hpp -- DLL 내부 전용 유틸리티
//    · JsonW      : 의존성 없는 최소 JSON 빌더
//    · KvArgs     : "key=value\n" 인자 파서
//    · Slot       : 중간 산출물 보관 (타입 태그 + 데이터)
//    · 파일 라이터 : PGM / PPM / CSV / BIN / NPY
//
//  이 헤더는 DLL 안에서만 쓰인다. exe 는 sim_abi.h 만 본다.
// ============================================================================
#pragma once

#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <cstdio>
#include <cctype>
#include <cstring>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <fstream>
#include <filesystem>

namespace sim {

// ---------------------------------------------------------------------------
// JSON 빌더 (쓰기 전용)
// ---------------------------------------------------------------------------
class JsonW {
public:
    JsonW() { s_.reserve(4096); }

    JsonW& beginObj()            { comma(); s_ += '{'; first_ = true; return *this; }
    JsonW& endObj()              { s_ += '}'; first_ = false; return *this; }
    JsonW& beginArr()            { comma(); s_ += '['; first_ = true; return *this; }
    JsonW& endArr()              { s_ += ']'; first_ = false; return *this; }

    JsonW& key(const std::string& k) { comma(); s_ += '"'; esc(k); s_ += "\":"; first_ = true; return *this; }

    JsonW& objKey(const std::string& k) { key(k); return beginObj(); }
    JsonW& arrKey(const std::string& k) { key(k); return beginArr(); }

    JsonW& val(const std::string& v) { comma(); s_ += '"'; esc(v); s_ += '"'; first_ = false; return *this; }
    JsonW& val(const char* v)        { return val(std::string(v ? v : "")); }
    JsonW& val(bool v)               { comma(); s_ += (v ? "true" : "false"); first_ = false; return *this; }
    JsonW& val(int v)                { comma(); s_ += std::to_string(v); first_ = false; return *this; }
    JsonW& val(long long v)          { comma(); s_ += std::to_string(v); first_ = false; return *this; }
    JsonW& val(size_t v)             { comma(); s_ += std::to_string(static_cast<long long>(v)); first_ = false; return *this; }
    JsonW& val(double v)             { comma(); s_ += num(v); first_ = false; return *this; }
    JsonW& val(float v)              { return val(static_cast<double>(v)); }

    template <typename T> JsonW& kv(const std::string& k, const T& v) { key(k); return val(v); }

    // 배열 헬퍼
    template <typename It>
    JsonW& arr(const std::string& k, It b, It e, size_t maxN = 4096) {
        arrKey(k);
        size_t n = 0;
        for (It it = b; it != e && n < maxN; ++it, ++n) val(*it);
        endArr();
        if (static_cast<size_t>(std::distance(b, e)) > maxN) kv(k + "_truncated", true);
        return *this;
    }

    const std::string& str() const { return s_; }
    void clear() { s_.clear(); first_ = true; }

private:
    void comma() { if (!first_) s_ += ','; first_ = false; }
    void esc(const std::string& v) {
        for (char c : v) {
            switch (c) {
                case '"':  s_ += "\\\""; break;
                case '\\': s_ += "\\\\"; break;
                case '\n': s_ += "\\n";  break;
                case '\r': s_ += "\\r";  break;
                case '\t': s_ += "\\t";  break;
                default:
                    if (static_cast<unsigned char>(c) < 0x20) {
                        char b[8];
                        snprintf(b, sizeof(b), "\\u%04x", c & 0xFF);
                        s_ += b;
                    } else {
                        s_ += c;
                    }
            }
        }
    }
    // NaN/Inf 는 JSON 표현이 없으므로 문자열로 escape 한다 (덤프에서 흔히 나온다).
    static std::string num(double v) {
        if (std::isnan(v)) return "\"NaN\"";
        if (std::isinf(v)) return v > 0 ? "\"Infinity\"" : "\"-Infinity\"";
        std::ostringstream os;
        os << std::setprecision(17) << v;
        return os.str();
    }
    std::string s_;
    bool first_ = true;
};

// ---------------------------------------------------------------------------
// "key=value\n" 인자 파서
// ---------------------------------------------------------------------------
class KvArgs {
public:
    explicit KvArgs(const char* s) {
        if (!s) return;
        std::string cur;
        std::istringstream is(s);
        std::string line;
        while (std::getline(is, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty() || line[0] == '#') continue;
            size_t eq = line.find('=');
            if (eq == std::string::npos) continue;
            std::string k = trim(line.substr(0, eq));
            std::string v = trim(line.substr(eq + 1));
            m_[k] = unescape(v);
        }
    }

    bool has(const std::string& k) const { return m_.count(k) != 0; }

    std::string str(const std::string& k, const std::string& def = "") const {
        auto it = m_.find(k);
        return it == m_.end() ? def : it->second;
    }
    int i(const std::string& k, int def = 0) const {
        auto it = m_.find(k);
        if (it == m_.end() || it->second.empty()) return def;
        try { return std::stoi(it->second, nullptr, 0); } catch (...) { return def; }
    }
    long long i64(const std::string& k, long long def = 0) const {
        auto it = m_.find(k);
        if (it == m_.end() || it->second.empty()) return def;
        try { return std::stoll(it->second, nullptr, 0); } catch (...) { return def; }
    }
    double d(const std::string& k, double def = 0.0) const {
        auto it = m_.find(k);
        if (it == m_.end() || it->second.empty()) return def;
        const std::string& v = it->second;
        if (v == "nan" || v == "NaN")   return std::nan("");
        if (v == "inf" || v == "Inf")   return HUGE_VAL;
        if (v == "-inf" || v == "-Inf") return -HUGE_VAL;
        try { return std::stod(v); } catch (...) { return def; }
    }
    bool b(const std::string& k, bool def = false) const {
        auto it = m_.find(k);
        if (it == m_.end()) return def;
        const std::string& v = it->second;
        return v == "1" || v == "true" || v == "True" || v == "yes" || v == "on";
    }
    // "1.0,2.0,3.0" 또는 "1.0 2.0 3.0"
    std::vector<double> dlist(const std::string& k) const {
        std::vector<double> out;
        std::string v = str(k);
        std::string cur;
        for (char c : v) {
            if (c == ',' || c == ' ' || c == ';' || c == '\t') {
                if (!cur.empty()) { try { out.push_back(std::stod(cur)); } catch (...) {} cur.clear(); }
            } else cur += c;
        }
        if (!cur.empty()) { try { out.push_back(std::stod(cur)); } catch (...) {} }
        return out;
    }

private:
    static std::string trim(const std::string& s) {
        size_t a = s.find_first_not_of(" \t");
        if (a == std::string::npos) return "";
        size_t b = s.find_last_not_of(" \t");
        return s.substr(a, b - a + 1);
    }
    // 값 안의 "\n" "\t" "\\" 만 되돌린다.
    static std::string unescape(const std::string& s) {
        std::string o;
        o.reserve(s.size());
        for (size_t i = 0; i < s.size(); ++i) {
            if (s[i] == '\\' && i + 1 < s.size()) {
                char n = s[i + 1];
                if (n == 'n') { o += '\n'; ++i; continue; }
                if (n == 't') { o += '\t'; ++i; continue; }
                if (n == 'r') { o += '\r'; ++i; continue; }
                if (n == '\\') { o += '\\'; ++i; continue; }
            }
            o += s[i];
        }
        return o;
    }
    std::map<std::string, std::string> m_;
};

// ---------------------------------------------------------------------------
// 통계
// ---------------------------------------------------------------------------
struct Stats {
    double min = 0, max = 0, mean = 0, stddev = 0, sum = 0;
    size_t count = 0, nanCount = 0, zeroCount = 0;

    template <typename T>
    static Stats of(const T* p, size_t n) {
        Stats s;
        s.count = n;
        if (!n) return s;
        double mn = HUGE_VAL, mx = -HUGE_VAL, acc = 0;
        size_t valid = 0;
        for (size_t i = 0; i < n; ++i) {
            double v = static_cast<double>(p[i]);
            if (std::isnan(v)) { ++s.nanCount; continue; }
            if (v == 0.0) ++s.zeroCount;
            mn = (std::min)(mn, v);
            mx = (std::max)(mx, v);
            acc += v;
            ++valid;
        }
        if (!valid) return s;
        s.min = mn; s.max = mx; s.sum = acc; s.mean = acc / valid;
        double sq = 0;
        for (size_t i = 0; i < n; ++i) {
            double v = static_cast<double>(p[i]);
            if (std::isnan(v)) continue;
            sq += (v - s.mean) * (v - s.mean);
        }
        s.stddev = std::sqrt(sq / valid);
        return s;
    }

    void writeTo(JsonW& j, const std::string& name) const {
        j.objKey(name)
            .kv("count", count).kv("min", min).kv("max", max)
            .kv("mean", mean).kv("stddev", stddev).kv("sum", sum)
            .kv("nan", nanCount).kv("zero", zeroCount)
         .endObj();
    }
};

// ---------------------------------------------------------------------------
// 파일 라이터
// ---------------------------------------------------------------------------
inline bool ensureDir(const std::string& d) {
    try {
        if (d.empty()) return false;
        if (!std::filesystem::exists(d)) std::filesystem::create_directories(d);
        return true;
    } catch (...) { return false; }
}

inline bool writePGM(const std::string& path, const uint8_t* p, int w, int h) {
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f << "P5\n" << w << " " << h << "\n255\n";
    f.write(reinterpret_cast<const char*>(p), static_cast<std::streamsize>(w) * h);
    return f.good();
}

inline bool writePPM(const std::string& path, const uint8_t* p, int w, int h) {
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f << "P6\n" << w << " " << h << "\n255\n";
    f.write(reinterpret_cast<const char*>(p), static_cast<std::streamsize>(w) * h * 3);
    return f.good();
}

// 임의 스칼라 버퍼를 min..max 로 정규화해 시각화용 PGM 으로.
template <typename T>
inline bool writeNormalizedPGM(const std::string& path, const T* p, int w, int h) {
    if (w <= 0 || h <= 0) return false;
    Stats s = Stats::of(p, static_cast<size_t>(w) * h);
    const double span = (s.max - s.min);
    std::vector<uint8_t> img(static_cast<size_t>(w) * h);
    for (size_t i = 0; i < img.size(); ++i) {
        double v = static_cast<double>(p[i]);
        if (std::isnan(v)) { img[i] = 0; continue; }
        img[i] = span > 0 ? static_cast<uint8_t>(std::lround((v - s.min) / span * 255.0)) : 0;
    }
    return writePGM(path, img.data(), w, h);
}

template <typename T>
inline bool writeCSV(const std::string& path, const T* p, int w, int h, int precision = 9) {
    std::ofstream f(path);
    if (!f) return false;
    f << std::setprecision(precision);
    if (h <= 1) {
        // 1차원: index,value
        f << "index,value\n";
        for (int i = 0; i < w; ++i) f << i << "," << +p[i] << "\n";
    } else {
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                if (x) f << ',';
                f << +p[static_cast<size_t>(y) * w + x];
            }
            f << "\n";
        }
    }
    return f.good();
}

inline bool writeBIN(const std::string& path, const void* p, size_t bytes) {
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(p), static_cast<std::streamsize>(bytes));
    return f.good();
}

// numpy .npy v1.0 (학습측 Python 코드와 bit-exact 대조용)
template <typename T>
inline bool writeNPY(const std::string& path, const T* p, const std::vector<int>& shape,
                     const char* dtype) {
    std::string hdr = "{'descr': '";
    hdr += dtype;
    hdr += "', 'fortran_order': False, 'shape': (";
    for (size_t i = 0; i < shape.size(); ++i) {
        hdr += std::to_string(shape[i]);
        if (shape.size() == 1 || i + 1 < shape.size()) hdr += ", ";
    }
    hdr += "), }";
    // 전체 헤더(magic10 + hdr + '\n')가 64바이트 배수가 되도록 공백 패딩
    size_t total = 10 + hdr.size() + 1;
    size_t pad = (64 - (total % 64)) % 64;
    hdr.append(pad, ' ');
    hdr += '\n';

    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    const char magic[] = "\x93NUMPY";
    f.write(magic, 6);
    const uint8_t ver[2] = { 1, 0 };
    f.write(reinterpret_cast<const char*>(ver), 2);
    const uint16_t hlen = static_cast<uint16_t>(hdr.size());
    f.write(reinterpret_cast<const char*>(&hlen), 2);
    f.write(hdr.data(), static_cast<std::streamsize>(hdr.size()));

    size_t n = 1;
    for (int s : shape) n *= static_cast<size_t>(s);
    f.write(reinterpret_cast<const char*>(p), static_cast<std::streamsize>(n * sizeof(T)));
    return f.good();
}

}  // namespace sim
