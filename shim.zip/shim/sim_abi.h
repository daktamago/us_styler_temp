// ============================================================================
//  sim_abi.h -- StyleUS 화이트박스 시뮬레이터 C-ABI
// ----------------------------------------------------------------------------
//  StyleUS_sim.dll (화이트박스 사본) 과 styleus_sim.exe (UI) 사이의 유일한 경계.
//
//  [설계 원칙]
//   1. 경계를 넘는 타입은 C 기본형 + const char* + 호출자 제공 버퍼뿐이다.
//      std::string / std::vector / 클래스는 절대 넘기지 않는다.
//      => exe 와 dll 의 컴파일러/CRT/_ITERATOR_DEBUG_LEVEL 이 달라도 안전하다.
//   2. 문자열 반환은 2단계다.
//        len = SIM_Call(...);            // 결과 JSON 의 바이트 길이를 돌려준다
//        SIM_FetchResult(ctx, buf, cap); // 실제 복사
//      버퍼 크기를 미리 알 수 없는 문제를 없앤다.
//   3. 모든 함수 인자는 "key=value\n" 텍스트 한 덩어리로 전달한다.
//      타입 변환은 DLL 쪽이 담당하며, 어떤 키를 받는지는 SIM_ListFunctions()
//      가 내보내는 매니페스트에 전부 기술되어 있다.
//      => UI 는 함수 목록/인자 폼을 DLL 에서 읽어 동적으로 구성한다.
//         DLL 이 바뀌면 UI 를 다시 빌드하지 않아도 따라간다.
// ============================================================================
#ifndef STYLEUS_SIM_ABI_H
#define STYLEUS_SIM_ABI_H

#include <stdint.h>

#ifdef SIMSHIM_EXPORTS
#define SIM_API __declspec(dllexport)
#else
#define SIM_API __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ABI 버전. UI 는 로드 직후 이 값을 확인하고 다르면 거부한다. */
#define SIM_ABI_VERSION 1

/* 반환 코드 (음수만 오류) */
#define SIM_OK               0
#define SIM_ERR_BADCTX      -1
#define SIM_ERR_UNKNOWN_FN  -2
#define SIM_ERR_BADARG      -3
#define SIM_ERR_MISSING_IN  -4   /* 선행 단계 산출물(슬롯)이 없음 */
#define SIM_ERR_IO          -5
#define SIM_ERR_EXCEPTION   -6
#define SIM_ERR_ABORTED     -7

typedef struct SimContext SimContext;

/* --- 수명 --------------------------------------------------------------- */
SIM_API int         SIM_AbiVersion(void);
/* 컴파일러/CRT/sizeof(RSDMR)/상수값 등. UI 리포트 헤더에 항상 표시할 것. */
SIM_API const char* SIM_BuildInfo(void);

SIM_API SimContext* SIM_Create(const char* outDir);
SIM_API void        SIM_Destroy(SimContext* ctx);

/* --- 설정 --------------------------------------------------------------- */
SIM_API void SIM_SetOutDir(SimContext* ctx, const char* dir);
/* 0=요약만  1=+스칼라  2=+CSV/이미지  3=+전체 버퍼 바이너리 */
SIM_API void SIM_SetDumpLevel(SimContext* ctx, int level);

/* --- 매니페스트 --------------------------------------------------------- */
/* 호출 가능한 함수 전체 목록을 JSON 으로 만든다. 반환값 = 바이트 길이. */
SIM_API int SIM_ListFunctions(SimContext* ctx);
/* 사전 정의된 체인 목록. */
SIM_API int SIM_ListChains(SimContext* ctx);
/* 현재 컨텍스트에 살아있는 슬롯(중간 산출물) 목록. */
SIM_API int SIM_ListSlots(SimContext* ctx);

/* --- 실행 --------------------------------------------------------------- */
/*
 * fn      : 매니페스트의 "name"
 * argsKv  : "key=value\n" 나열. 값에 개행이 필요하면 \n 이스케이프 사용.
 * 반환    : 결과 JSON 바이트 길이(>=0), 또는 SIM_ERR_*
 *           오류일 때도 결과 JSON 에 {"ok":false,"error":"..."} 가 담긴다.
 */
SIM_API int SIM_Call(SimContext* ctx, const char* fn, const char* argsKv);

/*
 * 사전 정의 체인 실행. 각 단계 산출물을 슬롯에 남기고 dumpLevel 에 따라
 * outDir 로 파일까지 떨어뜨린다.
 * stopAfter : 여기까지만 실행하고 멈춘다(빈 문자열이면 끝까지).
 */
SIM_API int SIM_Chain(SimContext* ctx, const char* chain, const char* argsKv,
                      const char* stopAfter);

/* --- 결과 회수 ---------------------------------------------------------- */
/* 직전 SIM_Call/SIM_Chain/SIM_List* 의 JSON 을 복사한다. 반환=복사 바이트 수. */
SIM_API int SIM_FetchResult(SimContext* ctx, char* buf, int cap);
/* 누적 로그(원본 LOG_INFO/LOG_ERROR 캡처 포함). 반환=복사 바이트 수. */
SIM_API int SIM_FetchLog(SimContext* ctx, char* buf, int cap);
SIM_API void SIM_ClearLog(SimContext* ctx);

/* --- 슬롯 --------------------------------------------------------------- */
/*
 * 슬롯을 파일로 저장한다.
 * fmt : "auto" | "pgm" | "ppm" | "csv" | "bin" | "npy" | "json"
 * 저장 경로는 결과 JSON 에 담긴다(SIM_FetchResult 로 회수).
 */
SIM_API int  SIM_DumpSlot(SimContext* ctx, const char* slot, const char* fmt);
SIM_API void SIM_ClearSlots(SimContext* ctx);

/* 외부 파일을 슬롯으로 직접 적재 (선행 단계를 건너뛰고 중간부터 재개할 때).
 * kind : "raw_i16" | "raw_f32" | "bytes" | "pgm" | "ppm"
 * argsKv 로 width/height 를 준다.  */
SIM_API int SIM_LoadSlot(SimContext* ctx, const char* slot, const char* kind,
                         const char* path, const char* argsKv);

/* --- 취소 플래그 (원본 g_bForceExit 직접 조작) --------------------------- */
SIM_API void SIM_SetForceExit(int on);
SIM_API int  SIM_GetForceExit(void);

#ifdef __cplusplus
}
#endif

#endif /* STYLEUS_SIM_ABI_H */
