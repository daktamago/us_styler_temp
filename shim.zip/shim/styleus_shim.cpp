// ============================================================================
//  styleus_shim.cpp -- StyleUS 화이트박스 시뮬레이터 DLL (StyleUS_sim.dll)
// ----------------------------------------------------------------------------
//  [왜 이런 구조인가]
//
//  styleus.cpp 의 dcmraw 네임스페이스 함수 32개는 static(internal linkage)이라
//  다른 번역 단위(TU)에서 링크할 수 없다. 흔한 대응은 "사본을 만들어 static 을
//  전부 제거"하는 것인데, 두 가지 이유로 채택하지 않았다.
//
//   (1) static 을 떼도 DLL export table 에는 올라가지 않는다. GetProcAddress 로
//       못 잡는다. 실제로 L1 함수 10개는 원본에서 이미 non-static 인데도 외부
//       호출이 불가능하다. __declspec(dllexport) 가 추가로 필요하다.
//   (2) 정규식으로 static 을 지우면 함수 내부의 지역 static(로그 파일 경로 캐시
//       styleus.cpp:122, Lanczos 상수표 :707, 시드 배열 :1482)까지 함께 지워져
//       동작이 바뀐다. 검증 도구가 검증 대상을 변형시키면 의미가 없다.
//
//  그래서 "유닛 빌드" 를 쓴다. 원본 .cpp 를 그대로 #include 해서 같은 TU 안으로
//  가져오면 static 함수 전부가 보인다. 원본은 한 글자도 고치지 않는다.
//  바깥으로는 extern "C" C-ABI 래퍼만 내보낸다 → 이름 맹글링도, STL 이 DLL
//  경계를 넘는 문제도, exe/dll CRT 불일치 문제도 전부 사라진다.
//
//  덤으로, 원본 함수가 아니라 RunStyleUSInference() 790줄 안에 인라인으로 박혀
//  있는 전처리 단계 S1~S12 도 이 파일에 "등가 재현 함수" 로 옮겨 담는다.
//  발견사항 #1(CV 패딩 경계검사 부재) #2(LQS silent failure) #12(hist ÷2048) 이
//  전부 그 인라인 구간에 있어서, 함수 42개만 열어서는 볼 수 없기 때문이다.
//  등가성은 원본 라인 번호를 주석으로 못 박고 로직을 1:1로 옮기는 것으로 담보하며,
//  실 DLL 전체 실행 결과와 대조해 드리프트를 잡는다.
// ============================================================================

#define SIMSHIM_EXPORTS
#define STYLEUS_EXPORTS   // 사본 DLL 도 RunStyleUSInference/ForceExitStyleUS 를 export 한다

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

// ---------------------------------------------------------------------------
// 원본을 통째로 이 TU 안으로. 이 아래에서 dcmraw::* 전부 접근 가능해진다.
//
// ★ 왜 워크스페이스 루트의 styleus.cpp 를 직접 가리키지 않는가:
//   MSVC 의 따옴표 include 는 "그 지시문을 담은 파일의 디렉터리" 를 가장 먼저
//   뒤진다. 루트의 styleus.cpp 가 #include "styleus.h" 를 하면 루트의 styleus.h
//   가 잡히는데, 그 파일은 공백이 소실되어 컴파일이 불가능하다 (/I 로 우선순위를
//   바꿀 수 없다). 그래서 tools/prepare_source.py 가
//     · styleus.cpp 를 바이트 단위로 동일하게 build_src/ 로 복사하고
//     · 복구된 헤더를 같은 디렉터리에 함께 배치한다
//   그러면 따옴표 include 가 자연스럽게 복구본을 집는다.
//   원본 파일은 하나도 건드리지 않으며, 복사본의 SHA-256 이 원본과 같은지
//   prepare_source.py 가 매번 검증한다.
// ---------------------------------------------------------------------------
#include "../build_src/styleus.cpp"

#include "sim_abi.h"
#include "sim_dump.hpp"

#include <map>
#include <functional>
#include <memory>
#include <streambuf>

// ============================================================================
//  빌드 타임 계약 검증
//   md §4.1 / 발견사항 #5 "RSDMR 패딩 가정" 을 여기서 확정한다.
//   전 멤버가 4바이트 크기·정렬이라 패딩이 0 이고, 다음 값이 성립해야 한다.
//   실패하면 Main SW 와 .rsdmr 해석이 어긋난다는 뜻이므로 즉시 빌드를 깬다.
// ============================================================================
static_assert(sizeof(RSDMR_P) == 24,  "RSDMR_P layout changed");
static_assert(sizeof(RSDMR_S) == 52,  "RSDMR_S layout changed");
static_assert(sizeof(RSDMR_M) == 16,  "RSDMR_M layout changed");
static_assert(sizeof(RSDMR_Z) == 20,  "RSDMR_Z layout changed");
static_assert(sizeof(RSDMR)   == 256, "sizeof(RSDMR) != 256 -- .rsdmr 총 1288 bytes 가정이 깨졌다");

namespace shim {

using dcmraw::Image8U;
using dcmraw::PointI;
using dcmraw::PointD;
using dcmraw::DicomHeader;
using dcmraw::ScanGeometry;
using dcmraw::SectorParam;

using sim::JsonW;
using sim::KvArgs;
using sim::Stats;

// ============================================================================
//  슬롯 -- 중간 산출물 보관소
//    체인 실행 시 각 단계 결과를 여기 남긴다. 다음 단계는 이름으로 집어간다.
//    UI 에서 "이 함수만 단독 실행" 을 눌렀을 때 필요한 입력이 슬롯에 없으면
//    SIM_ERR_MISSING_IN 을 돌려주고, 어떤 체인을 먼저 돌려야 하는지 알려준다.
// ============================================================================
enum class Kind { None, Img8, F32, F64, I16, Bytes, Pts, Geom, Hdr, Sect };

struct Slot {
    Kind kind = Kind::None;
    int  w = 0, h = 0;               // F32/F64/I16 의 논리적 2D 형상 (h<=1 이면 1D)
    Image8U              img;
    std::vector<float>   f32;
    std::vector<double>  f64;
    std::vector<int16_t> i16;
    std::vector<uint8_t> bytes;
    std::vector<PointI>  pts;
    ScanGeometry         geom;
    DicomHeader          hdr;
    SectorParam          sect;
    std::string          note;       // 어느 함수가 만들었는지

    size_t elemCount() const {
        switch (kind) {
            case Kind::Img8:  return img.pixels.size();
            case Kind::F32:   return f32.size();
            case Kind::F64:   return f64.size();
            case Kind::I16:   return i16.size();
            case Kind::Bytes: return bytes.size();
            case Kind::Pts:   return pts.size();
            default:          return 0;
        }
    }
    const char* kindName() const {
        switch (kind) {
            case Kind::Img8:  return "Image8U";
            case Kind::F32:   return "float32";
            case Kind::F64:   return "float64";
            case Kind::I16:   return "int16";
            case Kind::Bytes: return "bytes";
            case Kind::Pts:   return "PointI[]";
            case Kind::Geom:  return "ScanGeometry";
            case Kind::Hdr:   return "DicomHeader";
            case Kind::Sect:  return "SectorParam";
            default:          return "none";
        }
    }
};

// ============================================================================
//  std::cout / std::cerr 캡처
//    원본 WriteStyleUSLog() 는 콘솔로 찍는다(styleus.cpp:86,88). GUI 에는 콘솔이
//    없으므로 rdbuf 를 갈아끼워 문자열로 받는다. 파일 로그 쪽은 원본 그대로 둔다.
// ============================================================================
class OutCapture {
public:
    explicit OutCapture(std::string& sink) : sink_(sink) {
        oldOut_ = std::cout.rdbuf(ss_.rdbuf());
        oldErr_ = std::cerr.rdbuf(ss_.rdbuf());
    }
    ~OutCapture() {
        std::cout.rdbuf(oldOut_);
        std::cerr.rdbuf(oldErr_);
        sink_ += ss_.str();
    }
private:
    std::string&      sink_;
    std::stringstream ss_;
    std::streambuf*   oldOut_ = nullptr;
    std::streambuf*   oldErr_ = nullptr;
};

}  // namespace shim

// ============================================================================
//  SimContext
// ============================================================================
struct SimContext {
    std::string outDir = ".\\sim_out";
    int         dumpLevel = 2;
    std::map<std::string, shim::Slot> slots;
    std::string lastResult;
    std::string log;
    long long   callSeq = 0;
    // SIM_Chain 이 받은 인자 원문. 체인 각 단계가 배선 인자와 병합할 때 쓴다.
    std::string chainArgsRaw;

    shim::Slot* find(const std::string& n) {
        auto it = slots.find(n);
        return it == slots.end() ? nullptr : &it->second;
    }
    shim::Slot& put(const std::string& n) { return slots[n]; }
};

namespace shim {

// ---------------------------------------------------------------------------
// 슬롯 -> 파일. dumpLevel 에 따라 무엇까지 떨어뜨릴지 결정한다.
//   0 요약만 / 1 +스칼라 / 2 +CSV·이미지 / 3 +전체 버퍼 바이너리(.bin/.npy)
// ---------------------------------------------------------------------------
static std::string joinPath(const std::string& d, const std::string& f) {
    if (d.empty()) return f;
    char b = d.back();
    return (b == '\\' || b == '/') ? d + f : d + "\\" + f;
}

static void dumpSlot(SimContext& ctx, const std::string& name, const Slot& s,
                     JsonW& j, const std::string& forceFmt = "") {
    j.objKey(name);
    j.kv("kind", s.kindName());
    if (!s.note.empty()) j.kv("from", s.note);

    const bool wantFiles  = ctx.dumpLevel >= 2 || !forceFmt.empty();
    const bool wantBinary = ctx.dumpLevel >= 3 || forceFmt == "bin" || forceFmt == "npy";

    if (!sim::ensureDir(ctx.outDir)) {
        j.kv("dump_error", "cannot create outDir: " + ctx.outDir);
    }

    std::vector<std::string> files;

    switch (s.kind) {
        case Kind::Img8: {
            j.kv("width", s.img.width).kv("height", s.img.height).kv("channels", s.img.channels);
            if (!s.img.pixels.empty()) {
                Stats::of(s.img.pixels.data(), s.img.pixels.size()).writeTo(j, "stats");
                // 이진 마스크면 백색 픽셀 수가 가장 중요한 지표다
                size_t white = 0;
                for (uint8_t p : s.img.pixels) if (p == 255) ++white;
                j.kv("white_255", white);
            }
            if (wantFiles && !s.img.empty()) {
                if (s.img.channels == 1) {
                    std::string p = joinPath(ctx.outDir, name + ".pgm");
                    if (sim::writePGM(p, s.img.pixels.data(), s.img.width, s.img.height)) files.push_back(p);
                } else if (s.img.channels == 3) {
                    std::string p = joinPath(ctx.outDir, name + ".ppm");
                    if (sim::writePPM(p, s.img.pixels.data(), s.img.width, s.img.height)) files.push_back(p);
                }
            }
            if (wantBinary && !s.img.pixels.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".bin");
                if (sim::writeBIN(p, s.img.pixels.data(), s.img.pixels.size())) files.push_back(p);
            }
            break;
        }
        case Kind::F32: {
            j.kv("width", s.w).kv("height", s.h).kv("count", s.f32.size());
            if (!s.f32.empty()) Stats::of(s.f32.data(), s.f32.size()).writeTo(j, "stats");
            if (s.f32.size() <= 64) j.arr("values", s.f32.begin(), s.f32.end());
            if (wantFiles && !s.f32.empty()) {
                if (s.f32.size() <= 65536) {
                    std::string p = joinPath(ctx.outDir, name + ".csv");
                    if (sim::writeCSV(p, s.f32.data(), s.w ? s.w : (int)s.f32.size(), s.h)) files.push_back(p);
                }
                if (s.w > 1 && s.h > 1) {
                    std::string p = joinPath(ctx.outDir, name + "_view.pgm");
                    if (sim::writeNormalizedPGM(p, s.f32.data(), s.w, s.h)) files.push_back(p);
                }
            }
            if (wantBinary && !s.f32.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".npy");
                std::vector<int> shape = (s.h > 1) ? std::vector<int>{ s.h, s.w }
                                                   : std::vector<int>{ (int)s.f32.size() };
                if (sim::writeNPY(p, s.f32.data(), shape, "<f4")) files.push_back(p);
            }
            break;
        }
        case Kind::F64: {
            j.kv("width", s.w).kv("height", s.h).kv("count", s.f64.size());
            if (!s.f64.empty()) Stats::of(s.f64.data(), s.f64.size()).writeTo(j, "stats");
            if (s.f64.size() <= 64) j.arr("values", s.f64.begin(), s.f64.end());
            if (wantFiles && !s.f64.empty() && s.f64.size() <= 65536) {
                std::string p = joinPath(ctx.outDir, name + ".csv");
                if (sim::writeCSV(p, s.f64.data(), s.w ? s.w : (int)s.f64.size(), s.h)) files.push_back(p);
            }
            if (wantBinary && !s.f64.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".npy");
                std::vector<int> shape = (s.h > 1) ? std::vector<int>{ s.h, s.w }
                                                   : std::vector<int>{ (int)s.f64.size() };
                if (sim::writeNPY(p, s.f64.data(), shape, "<f8")) files.push_back(p);
            }
            break;
        }
        case Kind::I16: {
            j.kv("width", s.w).kv("height", s.h).kv("count", s.i16.size());
            if (!s.i16.empty()) Stats::of(s.i16.data(), s.i16.size()).writeTo(j, "stats");
            if (wantFiles && !s.i16.empty() && s.w > 1 && s.h > 1) {
                std::string p = joinPath(ctx.outDir, name + "_view.pgm");
                if (sim::writeNormalizedPGM(p, s.i16.data(), s.w, s.h)) files.push_back(p);
            }
            if (wantBinary && !s.i16.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".npy");
                std::vector<int> shape = (s.h > 1) ? std::vector<int>{ s.h, s.w }
                                                   : std::vector<int>{ (int)s.i16.size() };
                if (sim::writeNPY(p, s.i16.data(), shape, "<i2")) files.push_back(p);
                std::string b = joinPath(ctx.outDir, name + ".raw");
                if (sim::writeBIN(b, s.i16.data(), s.i16.size() * 2)) files.push_back(b);
            }
            break;
        }
        case Kind::Bytes: {
            j.kv("count", s.bytes.size());
            if (wantBinary && !s.bytes.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".bin");
                if (sim::writeBIN(p, s.bytes.data(), s.bytes.size())) files.push_back(p);
            }
            break;
        }
        case Kind::Pts: {
            j.kv("count", s.pts.size());
            if (!s.pts.empty()) {
                j.objKey("first").kv("x", s.pts.front().x).kv("y", s.pts.front().y).endObj();
                j.objKey("last").kv("x", s.pts.back().x).kv("y", s.pts.back().y).endObj();
            }
            if (wantFiles && !s.pts.empty()) {
                std::string p = joinPath(ctx.outDir, name + ".csv");
                std::ofstream f(p);
                if (f) {
                    f << "index,x,y\n";
                    for (size_t i = 0; i < s.pts.size(); ++i)
                        f << i << "," << s.pts[i].x << "," << s.pts[i].y << "\n";
                    files.push_back(p);
                }
            }
            break;
        }
        case Kind::Geom: {
            const ScanGeometry& g = s.geom;
            j.objKey("apex").kv("x", g.apex.x).kv("y", g.apex.y).endObj();
            j.kv("angle_halfSweep_deg", g.angle)
             .kv("maxInnerRad", g.maxInnerRad)
             .kv("maxOuterRad", g.maxOuterRad)
             .kv("multiFrame", g.multiFrame)
             .kv("photometricWarned", g.photometricWarned)
             .kv("original_width", g.original.width)
             .kv("original_height", g.original.height)
             .kv("original_channels", g.original.channels)
             .kv("splineCoeff_count", g.splineCoeff.size());
            // splineCoeff 는 1채널 입력일 때만 채워진다 (styleus.cpp:1585). 배타적 경로 확인용.
            j.kv("path", g.original.channels == 1 ? "SampleCubicSpline (gray)"
                                                  : "SampleBilinear (3ch)");
            break;
        }
        case Kind::Hdr: {
            const DicomHeader& d = s.hdr;
            j.kv("bigEndian", d.bigEndian).kv("explicitVR", d.explicitVR)
             .kv("transferSyntax", d.transferSyntax)
             .kv("rows", (int)d.rows).kv("cols", (int)d.cols)
             .kv("samplesPerPixel", (int)d.samplesPerPixel)
             .kv("bitsAllocated", (int)d.bitsAllocated)
             .kv("planarConfig", (int)d.planarConfig)
             .kv("photometric", d.photometric)
             .kv("numberOfFrames", (long long)d.numberOfFrames)
             .kv("pixelOffset", d.pixelOffset)
             .kv("pixelLength", (long long)d.pixelLength)
             .kv("encapsulated", d.encapsulated)
             .kv("buf_bytes", d.buf.size());
            break;
        }
        case Kind::Sect: {
            const SectorParam& p = s.sect;
            j.kv("ax", p.ax).kv("ay", p.ay).kv("halfSweep_deg", p.halfSweep)
             .kv("ri", p.ri).kv("ro", p.ro);
            break;
        }
        default: break;
    }

    if (!files.empty()) j.arr("files", files.begin(), files.end());
    j.endObj();
}

// ---------------------------------------------------------------------------
// 핸들러 시그니처
//   반환: SIM_OK 또는 SIM_ERR_*.  j 에는 결과를 직접 써 넣는다.
// ---------------------------------------------------------------------------
using Handler = int (*)(SimContext&, const KvArgs&, JsonW&);

struct ParamSpec {
    const char* name;
    const char* type;   // "string"|"int"|"double"|"bool"|"path"|"slot"|"dlist"
    const char* def;
    const char* desc;
};

struct FnSpec {
    const char*  name;
    const char*  layer;      // "L1".."L5", "S"
    int          srcLine;    // styleus.cpp 정의 라인
    const char*  tier;       // "A" 단독 / "B" 얕은 선행 / "C" 체인 필요
    bool         dead;       // 원본 파이프라인에서 호출되지 않는 함수
    const char*  needChain;  // 선행 체인 이름 ("" 면 불필요)
    const char*  desc;
    std::vector<ParamSpec>   params;
    std::vector<const char*> outSlots;
    Handler      fn;
};

// 전방 선언 -- shim_chains.inc 의 runChain() 이 함수 테이블을 조회한다.
// 테이블 자체는 .inc 들을 include 한 뒤에 만들어지므로 선언만 먼저 둔다.
static const FnSpec* findFn(const std::string& n);

// 슬롯 요구 헬퍼 -----------------------------------------------------------
static int needSlot(SimContext& ctx, const std::string& n, Kind k, JsonW& j,
                    const char* hint, Slot** out) {
    Slot* s = ctx.find(n);
    if (!s || s->kind != k) {
        j.kv("ok", false);
        j.kv("error", "required slot '" + n + "' is missing or wrong type");
        j.kv("hint", hint);
        return SIM_ERR_MISSING_IN;
    }
    *out = s;
    return SIM_OK;
}

static std::vector<uint8_t> readFileBytes(const std::string& path, std::string& err) {
    std::vector<uint8_t> out;
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { err = "cannot open: " + path; return out; }
    std::streamoff n = f.tellg();
    f.seekg(0);
    out.resize(static_cast<size_t>(n));
    f.read(reinterpret_cast<char*>(out.data()), n);
    return out;
}

// 원본과 동일한 5단계 탐색 후보를 재계산한다.
//   ★ 원본 로직을 후킹하거나 바꾸지 않는다. 실제 선택은 원본 함수가 하고,
//     이 함수는 "어떤 후보들이 존재하는가" 만 별도로 관찰해 리포트한다.
//     (md §10.4 "5개 후보 중 몇 번째에서 매칭됐는지" 기록 요구사항)
static std::vector<std::string> searchDirCandidates(const char* kind /*"raw"|"dicom"*/) {
    std::wstring dllDir = GetMyDllDirectory();
    std::wstring projectRoot = dllDir + L"\\..\\..\\";
    std::string rel1 = WideToMultiByte(projectRoot) + "..\\styleus_data\\" + kind;
    std::string rel2 = WideToMultiByte(projectRoot) + "styleus_data\\" + kind;
    return {
        CombinePath(INTERNAL_BASE_DIR, kind, ""),
        rel1,
        rel2,
        std::string("..\\styleus_data\\") + kind,
        std::string("..\\..\\styleus_data\\") + kind
    };
}

static void reportSearchDirs(JsonW& j, const char* kind, const std::string& selected) {
    auto dirs = searchDirCandidates(kind);
    j.arrKey("search_dirs");
    for (size_t i = 0; i < dirs.size(); ++i) {
        bool exists = false;
        try { exists = std::filesystem::exists(dirs[i]); } catch (...) {}
        bool hit = !selected.empty() &&
                   selected.compare(0, dirs[i].size(), dirs[i]) == 0;
        j.beginObj()
            .kv("rank", (int)i + 1)
            .kv("dir", dirs[i])
            .kv("exists", exists)
            .kv("matched", hit)
         .endObj();
    }
    j.endArr();
    j.kv("cwd", std::filesystem::current_path().string());
    j.kv("dll_dir", WideToMultiByte(GetMyDllDirectory()));
}

}  // namespace shim

// 함수/스테이지/체인 구현은 분리된 파일에 담는다 (이 파일이 너무 길어지지 않도록).
#include "shim_functions.inc"
#include "shim_stages.inc"
#include "shim_chains.inc"

namespace shim {

// ---------------------------------------------------------------------------
// 전체 함수 테이블 = L1~L5 함수 42개 + Aborted + S1~S12
// ---------------------------------------------------------------------------
static const std::vector<FnSpec>& allFunctions() {
    static std::vector<FnSpec> v = [] {
        std::vector<FnSpec> t;
        appendCoreFunctions(t);   // shim_functions.inc
        appendStageFunctions(t);  // shim_stages.inc
        return t;
    }();
    return v;
}

static const FnSpec* findFn(const std::string& n) {
    for (const FnSpec& f : allFunctions()) if (n == f.name) return &f;
    return nullptr;
}

static std::string buildInfoString() {
    std::ostringstream os;
    os << "StyleUS_sim.dll  abi=" << SIM_ABI_VERSION;
#if defined(_MSC_VER)
    os << "  compiler=MSVC " << _MSC_VER;
#elif defined(__clang__)
    os << "  compiler=clang " << __clang_major__ << "." << __clang_minor__;
#elif defined(__GNUC__)
    os << "  compiler=gcc " << __GNUC__ << "." << __GNUC_MINOR__;
#endif
#if defined(_DEBUG)
    os << "  crt=Debug";
#else
    os << "  crt=Release";
#endif
#if defined(_ITERATOR_DEBUG_LEVEL)
    os << "  IDL=" << _ITERATOR_DEBUG_LEVEL;
#endif
    os << "  sizeof(RSDMR)=" << sizeof(RSDMR)
       << "  rsdmr_file_bytes=" << (8 + sizeof(RSDMR) * 5)
       << "  ort=" << ORT_API_VERSION
       << "  STYLEUS_DUMMY_MODE=" << STYLEUS_DUMMY_MODE;
    os << "  | consts: kCvSampleSize=" << dcmraw::kCvSampleSize
       << " kCvScanline=" << dcmraw::kCvScanline
       << " kLqsSampleSize=" << dcmraw::kLqsSampleSize
       << " kLqsScanline=" << dcmraw::kLqsScanline
       << " kUpscaleFactor=" << dcmraw::kUpscaleFactor
       << " kOpenKernel=" << dcmraw::kOpenKernel
       << " kCloseKernel=" << dcmraw::kCloseKernel
       << " kMinSectorIoU=" << dcmraw::kMinSectorIoU
       << " kGuardRadialSrcPx=" << dcmraw::kGuardRadialSrcPx
       << " kGuardSweepDeg=" << dcmraw::kGuardSweepDeg;
    os << "  | INTERNAL_BASE_DIR=" << INTERNAL_BASE_DIR
       << "  INTERNAL_OUTPUT_DIR=" << INTERNAL_OUTPUT_DIR;
    return os.str();
}

}  // namespace shim

// ============================================================================
//  ABI 구현
// ============================================================================
using namespace shim;

static int storeResult(SimContext* ctx, const JsonW& j) {
    ctx->lastResult = j.str();
    return static_cast<int>(ctx->lastResult.size());
}

SIM_API int SIM_AbiVersion(void) { return SIM_ABI_VERSION; }

SIM_API const char* SIM_BuildInfo(void) {
    static std::string s = shim::buildInfoString();
    return s.c_str();
}

SIM_API SimContext* SIM_Create(const char* outDir) {
    try {
        SimContext* c = new SimContext();
        if (outDir && *outDir) c->outDir = outDir;
        sim::ensureDir(c->outDir);
        return c;
    } catch (...) { return nullptr; }
}

SIM_API void SIM_Destroy(SimContext* ctx) { delete ctx; }

SIM_API void SIM_SetOutDir(SimContext* ctx, const char* dir) {
    if (!ctx || !dir) return;
    ctx->outDir = dir;
    sim::ensureDir(ctx->outDir);
}

SIM_API void SIM_SetDumpLevel(SimContext* ctx, int level) {
    if (ctx) ctx->dumpLevel = (level < 0) ? 0 : (level > 3 ? 3 : level);
}

SIM_API int SIM_ListFunctions(SimContext* ctx) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj().kv("ok", true).kv("abi", SIM_ABI_VERSION);
    j.arrKey("functions");
    for (const FnSpec& f : allFunctions()) {
        j.beginObj()
            .kv("name", f.name)
            .kv("layer", f.layer)
            .kv("src_line", f.srcLine)
            .kv("tier", f.tier)
            .kv("dead_code", f.dead)
            .kv("need_chain", f.needChain)
            .kv("desc", f.desc)
            .kv("caution", cautionFor(f.name));   // 선택 즉시 UI 에 띄울 주의사항
        j.arrKey("params");
        for (const ParamSpec& p : f.params) {
            j.beginObj().kv("name", p.name).kv("type", p.type)
                        .kv("default", p.def).kv("desc", p.desc).endObj();
        }
        j.endArr();
        j.arr("out_slots", f.outSlots.begin(), f.outSlots.end());
        j.endObj();
    }
    j.endArr().endObj();
    return storeResult(ctx, j);
}

SIM_API int SIM_ListChains(SimContext* ctx) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj().kv("ok", true).arrKey("chains");
    for (const ChainSpec& c : allChains()) {
        j.beginObj().kv("name", c.name).kv("desc", c.desc);
        j.arrKey("steps");
        for (const ChainStep& s : c.steps) {
            j.beginObj().kv("id", s.id).kv("fn", s.fn).kv("src_line", s.srcLine)
                        .kv("note", s.note).endObj();
        }
        j.endArr();
        j.arrKey("params");
        for (const ParamSpec& p : c.params) {
            j.beginObj().kv("name", p.name).kv("type", p.type)
                        .kv("default", p.def).kv("desc", p.desc).endObj();
        }
        j.endArr().endObj();
    }
    j.endArr().endObj();
    return storeResult(ctx, j);
}

SIM_API int SIM_ListSlots(SimContext* ctx) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj().kv("ok", true).arrKey("slots");
    for (const auto& kv : ctx->slots) {
        j.beginObj().kv("name", kv.first).kv("kind", kv.second.kindName())
                    .kv("elements", kv.second.elemCount())
                    .kv("from", kv.second.note).endObj();
    }
    j.endArr().endObj();
    return storeResult(ctx, j);
}

SIM_API int SIM_Call(SimContext* ctx, const char* fn, const char* argsKv) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj();
    j.kv("call", fn ? fn : "");
    j.kv("seq", ++ctx->callSeq);

    const FnSpec* spec = fn ? findFn(fn) : nullptr;
    if (!spec) {
        j.kv("ok", false).kv("error", "unknown function").endObj();
        storeResult(ctx, j);
        return SIM_ERR_UNKNOWN_FN;
    }
    j.kv("layer", spec->layer).kv("src_line", spec->srcLine);
    if (spec->dead) {
        j.kv("warning",
             "이 함수는 export 함수에서 도달 불가능한 dead code 다. 원본 43개 중 6개가 "
             "여기 해당한다: WriteStyleUSLogW, CastToUint8Truncate, FindHighestCoordinates, "
             "CalculateAngleWithVertical, FindRadius (호출처 없음) / TraceOuterContour "
             "(CalculateAngleWithVertical 에서만 호출 -> 전이적 dead). "
             "AnalyzeDicom 은 FindRobustSeed->FloodFillMask->FitSector 로 직행한다. "
             "덤프는 정상 동작하지만 실제 파이프라인 결과에는 영향이 없다.");
    }

    if (const char* c = cautionFor(spec->name)) if (*c) j.kv("caution", c);

    KvArgs args(argsKv);
    int rc = SIM_ERR_EXCEPTION;
    {
        OutCapture cap(ctx->log);
        try {
            rc = spec->fn(*ctx, args, j);
        } catch (const std::exception& e) {
            j.kv("ok", false).kv("error", std::string("exception: ") + e.what());
            rc = SIM_ERR_EXCEPTION;
        } catch (...) {
            j.kv("ok", false).kv("error", "unknown exception");
            rc = SIM_ERR_EXCEPTION;
        }
    }
    if (rc == SIM_OK) j.kv("ok", true);
    j.endObj();
    storeResult(ctx, j);
    return rc == SIM_OK ? static_cast<int>(ctx->lastResult.size()) : rc;
}

SIM_API int SIM_Chain(SimContext* ctx, const char* chain, const char* argsKv,
                      const char* stopAfter) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj().kv("chain", chain ? chain : "").kv("seq", ++ctx->callSeq);

    const ChainSpec* cs = chain ? findChain(chain) : nullptr;
    if (!cs) {
        j.kv("ok", false).kv("error", "unknown chain").endObj();
        storeResult(ctx, j);
        return SIM_ERR_UNKNOWN_FN;
    }

    ctx->chainArgsRaw = argsKv ? argsKv : "";
    KvArgs args(argsKv);
    const std::string stop = stopAfter ? stopAfter : "";
    int rc = SIM_OK;
    {
        OutCapture cap(ctx->log);
        try {
            rc = runChain(*ctx, *cs, args, stop, j);
        } catch (const std::exception& e) {
            j.kv("ok", false).kv("error", std::string("exception: ") + e.what());
            rc = SIM_ERR_EXCEPTION;
        } catch (...) {
            j.kv("ok", false).kv("error", "unknown exception");
            rc = SIM_ERR_EXCEPTION;
        }
    }
    if (rc == SIM_OK) j.kv("ok", true);
    j.endObj();
    storeResult(ctx, j);
    return rc == SIM_OK ? static_cast<int>(ctx->lastResult.size()) : rc;
}

SIM_API int SIM_FetchResult(SimContext* ctx, char* buf, int cap) {
    if (!ctx || !buf || cap <= 0) return 0;
    int n = static_cast<int>(ctx->lastResult.size());
    if (n > cap - 1) n = cap - 1;
    memcpy(buf, ctx->lastResult.data(), static_cast<size_t>(n));
    buf[n] = '\0';
    return n;
}

SIM_API int SIM_FetchLog(SimContext* ctx, char* buf, int cap) {
    if (!ctx || !buf || cap <= 0) return 0;
    int n = static_cast<int>(ctx->log.size());
    if (n > cap - 1) n = cap - 1;
    memcpy(buf, ctx->log.data(), static_cast<size_t>(n));
    buf[n] = '\0';
    return n;
}

SIM_API void SIM_ClearLog(SimContext* ctx) { if (ctx) ctx->log.clear(); }

SIM_API int SIM_DumpSlot(SimContext* ctx, const char* slot, const char* fmt) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj();
    Slot* s = slot ? ctx->find(slot) : nullptr;
    if (!s) {
        j.kv("ok", false).kv("error", "no such slot").endObj();
        storeResult(ctx, j);
        return SIM_ERR_MISSING_IN;
    }
    std::string f = (fmt && *fmt) ? fmt : "auto";
    dumpSlot(*ctx, slot, *s, j, f == "auto" ? std::string() : f);
    j.kv("ok", true).endObj();
    return storeResult(ctx, j);
}

SIM_API void SIM_ClearSlots(SimContext* ctx) { if (ctx) ctx->slots.clear(); }

SIM_API int SIM_LoadSlot(SimContext* ctx, const char* slot, const char* kind,
                         const char* path, const char* argsKv) {
    if (!ctx) return SIM_ERR_BADCTX;
    JsonW j;
    j.beginObj().kv("load_slot", slot ? slot : "").kv("kind", kind ? kind : "");
    if (!slot || !kind || !path) {
        j.kv("ok", false).kv("error", "null argument").endObj();
        storeResult(ctx, j);
        return SIM_ERR_BADARG;
    }
    KvArgs args(argsKv);
    std::string err;
    std::vector<uint8_t> raw = readFileBytes(path, err);
    if (!err.empty()) {
        j.kv("ok", false).kv("error", err).endObj();
        storeResult(ctx, j);
        return SIM_ERR_IO;
    }

    const std::string k = kind;
    Slot& s = ctx->put(slot);
    s = Slot();
    s.note = std::string("SIM_LoadSlot(") + path + ")";
    int w = args.i("width", 0), h = args.i("height", 0);

    if (k == "raw_i16") {
        s.kind = Kind::I16;
        s.i16.resize(raw.size() / 2);
        memcpy(s.i16.data(), raw.data(), s.i16.size() * 2);
        s.w = w ? w : static_cast<int>(s.i16.size());
        s.h = h ? h : 1;
    } else if (k == "raw_f32") {
        s.kind = Kind::F32;
        s.f32.resize(raw.size() / 4);
        memcpy(s.f32.data(), raw.data(), s.f32.size() * 4);
        s.w = w ? w : static_cast<int>(s.f32.size());
        s.h = h ? h : 1;
    } else if (k == "bytes") {
        s.kind = Kind::Bytes;
        s.bytes = std::move(raw);
    } else if (k == "pgm" || k == "ppm") {
        // 최소 PGM/PPM 리더 (P5/P6, maxval 255)
        size_t p = 0;
        auto tok = [&]() -> std::string {
            while (p < raw.size() && (isspace(raw[p]) || raw[p] == '#')) {
                if (raw[p] == '#') { while (p < raw.size() && raw[p] != '\n') ++p; }
                else ++p;
            }
            std::string t;
            while (p < raw.size() && !isspace(raw[p])) t += static_cast<char>(raw[p++]);
            return t;
        };
        std::string magic = tok();
        int iw = atoi(tok().c_str()), ih = atoi(tok().c_str());
        int mx = atoi(tok().c_str());
        ++p;  // 헤더 뒤 공백 1개
        int ch = (magic == "P6") ? 3 : 1;
        if (mx != 255 || iw <= 0 || ih <= 0) {
            j.kv("ok", false).kv("error", "unsupported PGM/PPM (need maxval 255)").endObj();
            storeResult(ctx, j);
            return SIM_ERR_IO;
        }
        s.kind = Kind::Img8;
        s.img.create(iw, ih, ch);
        size_t need = static_cast<size_t>(iw) * ih * ch;
        if (raw.size() - p < need) {
            j.kv("ok", false).kv("error", "truncated pixel data").endObj();
            storeResult(ctx, j);
            return SIM_ERR_IO;
        }
        memcpy(s.img.pixels.data(), raw.data() + p, need);
    } else {
        j.kv("ok", false).kv("error", "unknown kind").endObj();
        storeResult(ctx, j);
        return SIM_ERR_BADARG;
    }

    dumpSlot(*ctx, slot, s, j);
    j.kv("ok", true).endObj();
    return storeResult(ctx, j);
}

SIM_API void SIM_SetForceExit(int on) { g_bForceExit = (on != 0); }
SIM_API int  SIM_GetForceExit(void)   { return g_bForceExit.load() ? 1 : 0; }
