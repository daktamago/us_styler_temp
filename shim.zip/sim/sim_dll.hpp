// ============================================================================
//  sim_dll.hpp -- StyleUS_sim.dll 동적 로더 (exe 전용)
// ----------------------------------------------------------------------------
//  암시적 링크(.lib) 대신 LoadLibrary 를 쓴다. 이유:
//   · DLL 을 바꿔 끼우며 비교할 수 있다 (사본 A vs 사본 B)
//   · DLL 을 다른 폴더에 두고 로드하면 GetMyDllDirectory() 기준점이 따라 움직인다
//     -> <dllDir> 상대 탐색 경로를 UI 조작 없이 관찰할 수 있다
//   · DLL 이 없거나 의존성이 빠져도 크래시 대신 진단 메시지를 낼 수 있다
//
//  경계를 넘는 것은 C 기본형과 const char* 뿐이므로(sim_abi.h 참고),
//  exe 와 DLL 의 CRT 가 달라도 안전하다.
// ============================================================================
#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <string>
#include <vector>

#include "../shim/sim_abi.h"

class SimDll {
public:
    ~SimDll() { unload(); }

    bool load(const std::string& path, std::string& err) {
        unload();
        // DLL 옆의 onnxruntime.dll 등을 찾을 수 있도록 탐색 경로를 추가한다.
        std::string dir = path;
        size_t p = dir.find_last_of("\\/");
        if (p != std::string::npos) dir = dir.substr(0, p);
        SetDllDirectoryA(dir.c_str());

        h_ = LoadLibraryA(path.c_str());
        if (!h_) {
            const DWORD e = GetLastError();
            err = "LoadLibrary 실패 (" + std::to_string(e) + "): " + path;
            if (e == 126)
                err += "\r\n  -> 모듈 자체 또는 의존 DLL 을 못 찾았다. "
                       "onnxruntime.dll 이 같은 폴더에 있는지, "
                       "Debug 빌드라면 VC++ 디버그 런타임(MSVCP140D/VCRUNTIME140D/ucrtbased)이 "
                       "설치돼 있는지 확인하라.";
            if (e == 193)
                err += "\r\n  -> 비트수 불일치다. exe 와 DLL 이 둘 다 x64 여야 한다.";
            return false;
        }

#define SIM_BIND(nm)                                                       \
        nm = reinterpret_cast<decltype(nm)>(                               \
                 reinterpret_cast<void*>(GetProcAddress(h_, #nm)));        \
        if (!nm) { err = "GetProcAddress 실패: " #nm; unload(); return false; }

        SIM_BIND(SIM_AbiVersion)
        SIM_BIND(SIM_BuildInfo)
        SIM_BIND(SIM_Create)
        SIM_BIND(SIM_Destroy)
        SIM_BIND(SIM_SetOutDir)
        SIM_BIND(SIM_SetDumpLevel)
        SIM_BIND(SIM_ListFunctions)
        SIM_BIND(SIM_ListChains)
        SIM_BIND(SIM_ListSlots)
        SIM_BIND(SIM_Call)
        SIM_BIND(SIM_Chain)
        SIM_BIND(SIM_FetchResult)
        SIM_BIND(SIM_FetchLog)
        SIM_BIND(SIM_ClearLog)
        SIM_BIND(SIM_DumpSlot)
        SIM_BIND(SIM_ClearSlots)
        SIM_BIND(SIM_LoadSlot)
        SIM_BIND(SIM_SetForceExit)
        SIM_BIND(SIM_GetForceExit)
#undef SIM_BIND

        const int abi = SIM_AbiVersion();
        if (abi != SIM_ABI_VERSION) {
            err = "ABI 버전 불일치: DLL=" + std::to_string(abi) +
                  ", exe=" + std::to_string(SIM_ABI_VERSION) +
                  "\r\n  -> DLL 과 exe 를 같은 소스에서 함께 다시 빌드하라.";
            unload();
            return false;
        }

        path_ = path;
        ctx_ = SIM_Create(nullptr);
        if (!ctx_) { err = "SIM_Create 실패"; unload(); return false; }
        return true;
    }

    void unload() {
        if (ctx_ && SIM_Destroy) { SIM_Destroy(ctx_); ctx_ = nullptr; }
        if (h_) { FreeLibrary(h_); h_ = nullptr; }
        path_.clear();
    }

    bool ok() const { return h_ != nullptr && ctx_ != nullptr; }
    const std::string& path() const { return path_; }
    SimContext* ctx() const { return ctx_; }

    // 직전 결과 JSON 을 통째로 가져온다 (버퍼 크기를 알아서 늘린다).
    std::string fetchResult() const {
        if (!ok()) return "";
        std::vector<char> buf(1 << 16);
        for (int tries = 0; tries < 8; ++tries) {
            const int n = SIM_FetchResult(ctx_, buf.data(), (int)buf.size());
            if (n < (int)buf.size() - 1) return std::string(buf.data(), (size_t)n);
            buf.resize(buf.size() * 4);
        }
        return std::string(buf.data());
    }

    std::string fetchLog() const {
        if (!ok()) return "";
        std::vector<char> buf(1 << 16);
        for (int tries = 0; tries < 8; ++tries) {
            const int n = SIM_FetchLog(ctx_, buf.data(), (int)buf.size());
            if (n < (int)buf.size() - 1) return std::string(buf.data(), (size_t)n);
            buf.resize(buf.size() * 4);
        }
        return std::string(buf.data());
    }

    // --- 바인딩된 함수 포인터 ---------------------------------------------
    int         (*SIM_AbiVersion)(void) = nullptr;
    const char* (*SIM_BuildInfo)(void) = nullptr;
    SimContext* (*SIM_Create)(const char*) = nullptr;
    void        (*SIM_Destroy)(SimContext*) = nullptr;
    void        (*SIM_SetOutDir)(SimContext*, const char*) = nullptr;
    void        (*SIM_SetDumpLevel)(SimContext*, int) = nullptr;
    int         (*SIM_ListFunctions)(SimContext*) = nullptr;
    int         (*SIM_ListChains)(SimContext*) = nullptr;
    int         (*SIM_ListSlots)(SimContext*) = nullptr;
    int         (*SIM_Call)(SimContext*, const char*, const char*) = nullptr;
    int         (*SIM_Chain)(SimContext*, const char*, const char*, const char*) = nullptr;
    int         (*SIM_FetchResult)(SimContext*, char*, int) = nullptr;
    int         (*SIM_FetchLog)(SimContext*, char*, int) = nullptr;
    void        (*SIM_ClearLog)(SimContext*) = nullptr;
    int         (*SIM_DumpSlot)(SimContext*, const char*, const char*) = nullptr;
    void        (*SIM_ClearSlots)(SimContext*) = nullptr;
    int         (*SIM_LoadSlot)(SimContext*, const char*, const char*, const char*, const char*) = nullptr;
    void        (*SIM_SetForceExit)(int) = nullptr;
    int         (*SIM_GetForceExit)(void) = nullptr;

private:
    HMODULE     h_ = nullptr;
    SimContext* ctx_ = nullptr;
    std::string path_;
};
