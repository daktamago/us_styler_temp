// ============================================================================
//  main.cpp -- styleus_sim.exe : StyleUS 화이트박스 시뮬레이터 UI
// ----------------------------------------------------------------------------
//  [구조] GUI 와 CLI 가 완전히 같은 코어(SimDll)를 쓴다.
//    · GUI : 함수 목록을 DLL 매니페스트에서 읽어 트리로 뿌리고, 선택한 함수의
//            인자 폼을 그 자리에서 만들어 준다. DLL 이 바뀌면 exe 를 다시
//            빌드하지 않아도 목록/인자가 따라간다.
//    · CLI : 같은 동작을 스크립트로 돌린다. 회귀 검증을 자동화할 수 있고,
//            GUI 화면 없이도 전 기능을 확인할 수 있다.
//
//  [의존성] Win32 API + comctl32 만 쓴다. 외부 라이브러리 없음.
//           Build Tools 2022 만 있으면 빌드된다.
// ============================================================================

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cstdio>

#include "sim_dll.hpp"
#include "sim_json.hpp"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")

// ---------------------------------------------------------------------------
// UTF-8 <-> UTF-16
//   소스가 UTF-8 이므로 Win32 로 넘길 때 반드시 변환한다. A 계열 API 로 바로
//   넘기면 ACP 해석이 되어 한글이 깨진다.
// ---------------------------------------------------------------------------
static std::wstring U(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
static std::string A(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

// ---------------------------------------------------------------------------
// 매니페스트 모델
// ---------------------------------------------------------------------------
struct Param {
    std::string name, type, def, desc;
};
struct FnEntry {
    std::string name, layer, tier, needChain, desc;
    std::string caution;   // 선택 즉시 띄울 주의사항 (없으면 빈 문자열)
    int  srcLine = 0;
    bool dead = false;
    std::vector<Param> params;
    std::vector<std::string> outSlots;
};
struct ChainStepEntry {
    std::string id, fn, note;
    int srcLine = 0;
};
struct ChainEntry {
    std::string name, desc;
    std::vector<ChainStepEntry> steps;
    std::vector<Param> params;
};

struct Manifest {
    std::vector<FnEntry>    fns;
    std::vector<ChainEntry> chains;

    const FnEntry* fn(const std::string& n) const {
        for (const auto& f : fns) if (f.name == n) return &f;
        return nullptr;
    }
    const ChainEntry* chain(const std::string& n) const {
        for (const auto& c : chains) if (c.name == n) return &c;
        return nullptr;
    }
    // 함수 이름 -> 그 함수가 속한 체인 단계 id (선행 체인 실행용)
    std::string stepIdFor(const std::string& chainName, const std::string& fnName) const {
        const ChainEntry* c = chain(chainName);
        if (!c) return "";
        for (const auto& s : c->steps) if (s.fn == fnName) return s.id;
        return "";
    }
};

static std::vector<Param> parseParams(const sj::Value* arr) {
    std::vector<Param> out;
    if (!arr || arr->type != sj::Type::Array) return out;
    for (const auto& e : arr->arr) {
        Param p;
        p.name = e->s("name");
        p.type = e->s("type");
        p.def  = e->s("default");
        p.desc = e->s("desc");
        out.push_back(p);
    }
    return out;
}

static bool loadManifest(SimDll& dll, Manifest& mf, std::string& err) {
    mf.fns.clear();
    mf.chains.clear();

    if (dll.SIM_ListFunctions(dll.ctx()) < 0) { err = "SIM_ListFunctions 실패"; return false; }
    sj::ValuePtr root = sj::Parser::parse(dll.fetchResult());
    if (!root) { err = "함수 매니페스트 JSON 파싱 실패"; return false; }
    const sj::Value* fa = root->find("functions");
    if (!fa || fa->type != sj::Type::Array) { err = "functions 배열 없음"; return false; }
    for (const auto& e : fa->arr) {
        FnEntry f;
        f.name      = e->s("name");
        f.layer     = e->s("layer");
        f.tier      = e->s("tier");
        f.needChain = e->s("need_chain");
        f.desc      = e->s("desc");
        f.caution   = e->s("caution");
        f.srcLine   = e->integer("src_line");
        f.dead      = e->boolean("dead_code");
        f.params    = parseParams(e->find("params"));
        if (const sj::Value* os = e->find("out_slots"))
            for (const auto& s : os->arr) f.outSlots.push_back(s->str);
        mf.fns.push_back(f);
    }

    if (dll.SIM_ListChains(dll.ctx()) < 0) { err = "SIM_ListChains 실패"; return false; }
    sj::ValuePtr croot = sj::Parser::parse(dll.fetchResult());
    if (croot) {
        if (const sj::Value* ca = croot->find("chains")) {
            for (const auto& e : ca->arr) {
                ChainEntry c;
                c.name = e->s("name");
                c.desc = e->s("desc");
                c.params = parseParams(e->find("params"));
                if (const sj::Value* st = e->find("steps")) {
                    for (const auto& s : st->arr) {
                        ChainStepEntry cs;
                        cs.id = s->s("id");
                        cs.fn = s->s("fn");
                        cs.note = s->s("note");
                        cs.srcLine = s->integer("src_line");
                        c.steps.push_back(cs);
                    }
                }
                mf.chains.push_back(c);
            }
        }
    }
    return true;
}

// ============================================================================
//  CLI
// ============================================================================
static void cliPrint(const std::string& utf8) {
    const std::wstring w = U(utf8);
    DWORD written = 0;
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (h && h != INVALID_HANDLE_VALUE &&
        WriteConsoleW(h, w.c_str(), (DWORD)w.size(), &written, nullptr)) return;
    // 파이프로 리다이렉트된 경우
    fputs(utf8.c_str(), stdout);
}

static int cliUsage() {
    cliPrint(
        "styleus_sim.exe -- StyleUS 화이트박스 시뮬레이터\n"
        "\n"
        "GUI  : 인자 없이 실행\n"
        "CLI  : styleus_sim.exe --cli <명령> [옵션]\n"
        "\n"
        "공통 옵션\n"
        "  --dll <path>        대상 DLL (기본: exe 옆의 StyleUS_sim.dll)\n"
        "  --out <dir>         덤프 출력 폴더 (기본: .\\sim_out)\n"
        "  --dump-level 0..3   0=요약 1=+스칼라 2=+CSV/이미지 3=+전체 버퍼\n"
        "  --raw               결과 JSON 을 정리하지 않고 그대로 출력\n"
        "\n"
        "명령\n"
        "  info                     빌드 정보 / 계약 상수 출력\n"
        "  list [--dead] [--tier X] 호출 가능 함수 목록\n"
        "  chains                   사전 정의 체인 목록\n"
        "  call <fn> [k=v ...]      함수 1개 실행\n"
        "  chain <name> [--stop-after <id>] [k=v ...]\n"
        "                           체인 실행\n"
        "  auto <fn> [k=v ...]      선행 체인을 자동으로 돌린 뒤 그 함수까지 실행\n"
        "  load <slot> <kind> <path> [k=v ...]\n"
        "                           외부 파일을 슬롯으로 적재\n"
        "                           kind: raw_i16 | raw_f32 | bytes | pgm | ppm\n"
        "  slots                    현재 슬롯 목록\n"
        "  dump <slot> [fmt]        슬롯을 파일로 저장 (auto|pgm|ppm|csv|bin|npy)\n"
        "  log                      누적 로그 출력\n"
        "\n"
        "예)\n"
        "  styleus_sim.exe --cli call IsLongFormVR\n"
        "  styleus_sim.exe --cli call S12_WriteIni lqs7=50,40,9,45,-15,0.0000123,0.0000456\n"
        "  styleus_sim.exe --cli chain mask path=C:\\dump\\specialist_mode_assets\\dicom\\style_01.dcm\n"
        "  styleus_sim.exe --cli auto FitSector path=...\\style_01.dcm\n"
        "  styleus_sim.exe --cli load cv_raw raw_i16 style_01_x528_y177_CV.raw width=528 height=177\n"
        "  styleus_sim.exe --cli chain cv_tensors --dump-level 3\n");
    return 0;
}

static std::string defaultDllPath() {
    wchar_t buf[MAX_PATH] = { 0 };
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    std::wstring p(buf);
    size_t s = p.find_last_of(L"\\/");
    if (s != std::wstring::npos) p = p.substr(0, s + 1);
    return A(p + L"StyleUS_sim.dll");
}

static int runCli(const std::vector<std::string>& argv) {
    std::string dllPath = defaultDllPath();
    std::string outDir = ".\\sim_out";
    int dumpLevel = 2;
    bool raw = false;

    // 옵션과 위치 인자 분리
    std::vector<std::string> pos;
    std::string stopAfter;
    for (size_t i = 0; i < argv.size(); ++i) {
        const std::string& a = argv[i];
        if (a == "--dll" && i + 1 < argv.size())            dllPath = argv[++i];
        else if (a == "--out" && i + 1 < argv.size())       outDir = argv[++i];
        else if (a == "--dump-level" && i + 1 < argv.size()) dumpLevel = atoi(argv[++i].c_str());
        else if (a == "--stop-after" && i + 1 < argv.size()) stopAfter = argv[++i];
        else if (a == "--raw")                              raw = true;
        else if (a == "--dead" || a.rfind("--tier", 0) == 0) pos.push_back(a);
        else pos.push_back(a);
    }
    if (pos.empty()) return cliUsage();

    SimDll dll;
    std::string err;
    if (!dll.load(dllPath, err)) {
        cliPrint("[오류] " + err + "\n");
        return 2;
    }
    dll.SIM_SetOutDir(dll.ctx(), outDir.c_str());
    dll.SIM_SetDumpLevel(dll.ctx(), dumpLevel);

    Manifest mf;
    if (!loadManifest(dll, mf, err)) {
        cliPrint("[오류] " + err + "\n");
        return 2;
    }

    auto emit = [&](int rc) {
        const std::string r = dll.fetchResult();
        cliPrint(raw ? r + "\n" : sj::pretty(r) + "\n");
        if (rc < 0) cliPrint("[실패] 반환 코드 " + std::to_string(rc) + "\n");
        return rc < 0 ? 1 : 0;
    };
    auto kvFrom = [&](size_t from) {
        std::string s;
        for (size_t i = from; i < pos.size(); ++i)
            if (pos[i].find('=') != std::string::npos) s += pos[i] + "\n";
        return s;
    };

    const std::string cmd = pos[0];

    if (cmd == "info") {
        cliPrint(std::string(dll.SIM_BuildInfo()) + "\n");
        cliPrint("DLL: " + dll.path() + "\n");
        cliPrint("함수 " + std::to_string(mf.fns.size()) +
                 "개, 체인 " + std::to_string(mf.chains.size()) + "개\n");
        return 0;
    }

    if (cmd == "list") {
        bool onlyDead = std::find(pos.begin(), pos.end(), "--dead") != pos.end();
        std::string layerNow;
        int live = 0, dead = 0;
        for (const auto& f : mf.fns) {
            if (onlyDead && !f.dead) continue;
            if (f.layer != layerNow) {
                layerNow = f.layer;
                cliPrint("\n[" + layerNow + "]\n");
            }
            (f.dead ? dead : live)++;
            char line[512];
            snprintf(line, sizeof(line), "  %-28s L%-5d tier=%s %s%s\n",
                     f.name.c_str(), f.srcLine, f.tier.c_str(),
                     f.dead ? "[DEAD] " : "",
                     f.needChain.empty() ? "" : ("chain=" + f.needChain).c_str());
            cliPrint(line);
            cliPrint("      " + f.desc + "\n");
            if (!f.caution.empty()) {
                std::string c = f.caution;
                std::string ind = "      ! ";
                for (char ch : c) { ind += ch; if (ch == '\n') ind += "        "; }
                cliPrint(ind + "\n");
            }
        }
        cliPrint("\n총 " + std::to_string(live + dead) + "개 (live " +
                 std::to_string(live) + ", dead " + std::to_string(dead) + ")\n");
        return 0;
    }

    if (cmd == "chains") {
        for (const auto& c : mf.chains) {
            cliPrint("\n== " + c.name + " ==\n  " + c.desc + "\n");
            for (size_t i = 0; i < c.steps.size(); ++i) {
                char line[512];
                snprintf(line, sizeof(line), "   %2d. %-22s -> %-26s (원본 L%d)\n",
                         (int)i + 1, c.steps[i].id.c_str(), c.steps[i].fn.c_str(),
                         c.steps[i].srcLine);
                cliPrint(line);
            }
        }
        return 0;
    }

    if (cmd == "call" && pos.size() >= 2)
        return emit(dll.SIM_Call(dll.ctx(), pos[1].c_str(), kvFrom(2).c_str()));

    if (cmd == "chain" && pos.size() >= 2)
        return emit(dll.SIM_Chain(dll.ctx(), pos[1].c_str(), kvFrom(2).c_str(), stopAfter.c_str()));

    if (cmd == "auto" && pos.size() >= 2) {
        const FnEntry* f = mf.fn(pos[1]);
        if (!f) { cliPrint("[오류] 알 수 없는 함수: " + pos[1] + "\n"); return 2; }
        const std::string kv = kvFrom(2);
        if (!f->needChain.empty()) {
            const std::string sid = mf.stepIdFor(f->needChain, f->name);
            cliPrint("[선행 체인] " + f->needChain +
                     (sid.empty() ? "" : "  (--stop-after " + sid + ")") + "\n");
            const int rc = dll.SIM_Chain(dll.ctx(), f->needChain.c_str(), kv.c_str(), sid.c_str());
            const std::string r = dll.fetchResult();
            cliPrint(raw ? r + "\n" : sj::pretty(r) + "\n");
            if (rc < 0) { cliPrint("[실패] 선행 체인이 실패했다\n"); return 1; }
            if (!sid.empty()) return 0;   // 체인 안에서 이미 실행됨
        }
        cliPrint("[함수 실행] " + f->name + "\n");
        return emit(dll.SIM_Call(dll.ctx(), f->name.c_str(), kv.c_str()));
    }

    if (cmd == "load" && pos.size() >= 4)
        return emit(dll.SIM_LoadSlot(dll.ctx(), pos[1].c_str(), pos[2].c_str(),
                                     pos[3].c_str(), kvFrom(4).c_str()));

    if (cmd == "slots")
        return emit(dll.SIM_ListSlots(dll.ctx()));

    if (cmd == "dump" && pos.size() >= 2)
        return emit(dll.SIM_DumpSlot(dll.ctx(), pos[1].c_str(),
                                     pos.size() >= 3 ? pos[2].c_str() : "auto"));

    if (cmd == "log") {
        cliPrint(dll.fetchLog() + "\n");
        return 0;
    }

    cliPrint("[오류] 알 수 없는 명령: " + cmd + "\n\n");
    return cliUsage();
}

// ============================================================================
//  GUI
// ============================================================================
enum : int {
    ID_TREE = 1000, ID_OUT_EDIT, ID_RESULT, ID_TAB, ID_EXTRA,
    ID_BTN_LOADDLL, ID_BTN_OUTDIR, ID_BTN_RUN, ID_BTN_AUTO,
    ID_BTN_SLOTS, ID_BTN_CLEARSLOTS, ID_BTN_CLEARLOG, ID_BTN_DUMP,
    ID_CMB_DUMPLEVEL,
    ID_PARAM_BASE = 2000,   // 인자 에디트: ID_PARAM_BASE + i
    ID_BROWSE_BASE = 3000,  // 인자 찾아보기 버튼
};

struct Gui {
    HWND hwnd = nullptr, tree = nullptr, result = nullptr, tab = nullptr;
    HWND outEdit = nullptr, dumpCombo = nullptr, extra = nullptr, desc = nullptr;
    HWND paramHost = nullptr;
    HFONT fontUI = nullptr, fontMono = nullptr;

    SimDll   dll;
    Manifest mf;

    // 현재 선택
    bool  isChain = false;
    std::string selName;
    std::vector<HWND> paramEdits;
    std::vector<Param> curParams;

    std::string lastResult, lastLog;
    int  activeTab = 0;
};
static Gui g;

static void setResultText(const std::string& utf8) {
    SetWindowTextW(g.result, U(utf8).c_str());
}

static void refreshTab() {
    switch (g.activeTab) {
        case 0: setResultText(g.lastResult.empty() ? "(결과 없음)" : sj::pretty(g.lastResult)); break;
        case 1: setResultText(g.lastLog.empty() ? "(로그 없음)" : g.lastLog); break;
        case 2: {
            std::string s;
            if (g.dll.ok()) {
                s += "DLL : " + g.dll.path() + "\r\n\r\n";
                s += std::string(g.dll.SIM_BuildInfo()) + "\r\n\r\n";
            } else {
                s += "DLL 이 로드되지 않았다.\r\n\r\n";
            }
            s += "함수 " + std::to_string(g.mf.fns.size()) +
                 "개 / 체인 " + std::to_string(g.mf.chains.size()) + "개\r\n\r\n";
            int dead = 0;
            for (const auto& f : g.mf.fns) if (f.dead) ++dead;
            s += "dead code " + std::to_string(dead) + "개 (원본 파이프라인에서 도달 불가):\r\n";
            for (const auto& f : g.mf.fns)
                if (f.dead) s += "  - " + f.name + "  (원본 L" + std::to_string(f.srcLine) + ")\r\n";
            setResultText(s);
            break;
        }
    }
    SendMessageW(g.result, EM_SETSEL, 0, 0);
    SendMessageW(g.result, EM_SCROLLCARET, 0, 0);
}

static void afterCall(int rc) {
    g.lastResult = g.dll.fetchResult();
    g.lastLog = g.dll.fetchLog();
    if (rc < 0) g.lastResult += "\n\n[반환 코드 " + std::to_string(rc) + "]";
    g.activeTab = 0;
    TabCtrl_SetCurSel(g.tab, 0);
    refreshTab();
}

// --- 인자 폼 동적 생성 ------------------------------------------------------
static void clearParams() {
    for (HWND h : g.paramEdits) if (h) DestroyWindow(h);
    g.paramEdits.clear();
    // 라벨/버튼도 함께 정리
    HWND child = GetWindow(g.paramHost, GW_CHILD);
    while (child) {
        HWND next = GetWindow(child, GW_HWNDNEXT);
        DestroyWindow(child);
        child = next;
    }
    g.curParams.clear();
}

static void buildParams(const std::vector<Param>& ps, const std::string& description) {
    clearParams();
    g.curParams = ps;
    SetWindowTextW(g.desc, U(description).c_str());

    RECT rc;
    GetClientRect(g.paramHost, &rc);
    const int labelW = 150, rowH = 24, pad = 4;
    const int editX = labelW + pad * 2;
    int y = pad;

    for (size_t i = 0; i < ps.size(); ++i) {
        const Param& p = ps[i];
        const std::wstring label = U(p.name + " (" + p.type + ")");
        CreateWindowExW(0, L"STATIC", label.c_str(), WS_CHILD | WS_VISIBLE | SS_LEFT,
                        pad, y + 3, labelW, rowH - 6, g.paramHost, nullptr, nullptr, nullptr);

        const bool isPath = (p.type == "path");
        const int editW = rc.right - editX - pad - (isPath ? 30 : 0);
        HWND e = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", U(p.def).c_str(),
                                 WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                                 editX, y, editW, rowH - 2, g.paramHost,
                                 (HMENU)(INT_PTR)(ID_PARAM_BASE + (int)i), nullptr, nullptr);
        g.paramEdits.push_back(e);

        if (isPath) {
            CreateWindowExW(0, L"BUTTON", L"...", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                            editX + editW + 2, y, 26, rowH - 2, g.paramHost,
                            (HMENU)(INT_PTR)(ID_BROWSE_BASE + (int)i), nullptr, nullptr);
        }
        y += rowH;
    }

    // 폰트 적용
    HWND child = GetWindow(g.paramHost, GW_CHILD);
    while (child) {
        SendMessageW(child, WM_SETFONT, (WPARAM)g.fontUI, TRUE);
        child = GetWindow(child, GW_HWNDNEXT);
    }
    InvalidateRect(g.paramHost, nullptr, TRUE);
}

static std::string collectArgs() {
    std::string kv;
    for (size_t i = 0; i < g.paramEdits.size() && i < g.curParams.size(); ++i) {
        wchar_t buf[2048] = { 0 };
        GetWindowTextW(g.paramEdits[i], buf, 2048);
        const std::string v = A(buf);
        if (v.empty()) continue;            // 비우면 DLL 기본값이 적용된다
        kv += g.curParams[i].name + "=" + v + "\n";
    }
    wchar_t ex[4096] = { 0 };
    GetWindowTextW(g.extra, ex, 4096);
    std::string extra = A(ex);
    if (!extra.empty()) {
        // 줄바꿈을 그대로 이어붙인다
        if (extra.back() != '\n') extra += '\n';
        kv += extra;
    }
    return kv;
}

// --- 트리 ------------------------------------------------------------------
struct TreeRef { bool chain; int index; };
static std::vector<TreeRef> g_treeRefs;

static void fillTree() {
    TreeView_DeleteAllItems(g.tree);
    g_treeRefs.clear();

    struct Group { const char* key; const char* title; };
    static const Group groups[] = {
        { "L1",   "L1  경로 / 로그" },
        { "L2",   "L2  DICOM 파서" },
        { "L3",   "L3  영상 처리" },
        { "L4",   "L4  부채꼴 기하 추정" },
        { "L5",   "L5  파이프라인 통합" },
        { "S",    "S   인라인 단계 (RunStyleUSInference 내부)" },
        { "TOOL", "도구 (원본 함수 아님)" },
    };

    for (const Group& grp : groups) {
        int count = 0;
        for (const auto& f : g.mf.fns) if (f.layer == grp.key) ++count;
        if (!count) continue;

        TVINSERTSTRUCTW ti = {};
        ti.hParent = TVI_ROOT;
        ti.hInsertAfter = TVI_LAST;
        ti.item.mask = TVIF_TEXT | TVIF_PARAM;
        const std::wstring gt = U(std::string(grp.title) + "   (" + std::to_string(count) + ")");
        ti.item.pszText = const_cast<wchar_t*>(gt.c_str());
        ti.item.lParam = -1;
        HTREEITEM root = TreeView_InsertItem(g.tree, &ti);

        for (size_t i = 0; i < g.mf.fns.size(); ++i) {
            const FnEntry& f = g.mf.fns[i];
            if (f.layer != grp.key) continue;
            std::string label = f.name;
            if (f.dead) label += "   [dead]";
            else if (f.tier == "A") label += "   [단독]";
            else if (!f.needChain.empty()) label += "   [체인:" + f.needChain + "]";

            TVINSERTSTRUCTW c = {};
            c.hParent = root;
            c.hInsertAfter = TVI_LAST;
            c.item.mask = TVIF_TEXT | TVIF_PARAM;
            const std::wstring wl = U(label);
            c.item.pszText = const_cast<wchar_t*>(wl.c_str());
            c.item.lParam = (LPARAM)g_treeRefs.size();
            g_treeRefs.push_back({ false, (int)i });
            TreeView_InsertItem(g.tree, &c);
        }
        TreeView_Expand(g.tree, root, TVE_EXPAND);
    }

    if (!g.mf.chains.empty()) {
        TVINSERTSTRUCTW ti = {};
        ti.hParent = TVI_ROOT;
        ti.hInsertAfter = TVI_LAST;
        ti.item.mask = TVIF_TEXT | TVIF_PARAM;
        const std::wstring gt = U("체인 (선행 단계 자동 실행)   (" +
                                  std::to_string(g.mf.chains.size()) + ")");
        ti.item.pszText = const_cast<wchar_t*>(gt.c_str());
        ti.item.lParam = -1;
        HTREEITEM root = TreeView_InsertItem(g.tree, &ti);

        for (size_t i = 0; i < g.mf.chains.size(); ++i) {
            TVINSERTSTRUCTW c = {};
            c.hParent = root;
            c.hInsertAfter = TVI_LAST;
            c.item.mask = TVIF_TEXT | TVIF_PARAM;
            const std::wstring wl = U(g.mf.chains[i].name + "   (" +
                                      std::to_string(g.mf.chains[i].steps.size()) + "단계)");
            c.item.pszText = const_cast<wchar_t*>(wl.c_str());
            c.item.lParam = (LPARAM)g_treeRefs.size();
            g_treeRefs.push_back({ true, (int)i });
            TreeView_InsertItem(g.tree, &c);
        }
        TreeView_Expand(g.tree, root, TVE_EXPAND);
    }
}

static void onSelect(HTREEITEM item) {
    TVITEMW ti = {};
    ti.mask = TVIF_PARAM;
    ti.hItem = item;
    if (!TreeView_GetItem(g.tree, &ti) || ti.lParam < 0) return;
    const TreeRef& r = g_treeRefs[(size_t)ti.lParam];

    g.isChain = r.chain;
    if (r.chain) {
        const ChainEntry& c = g.mf.chains[(size_t)r.index];
        g.selName = c.name;
        std::string d = "[체인] " + c.name + "\r\n" + c.desc + "\r\n\r\n단계:\r\n";
        for (size_t i = 0; i < c.steps.size(); ++i) {
            d += "  " + std::to_string(i + 1) + ". " + c.steps[i].id +
                 "  ->  " + c.steps[i].fn +
                 "   (원본 L" + std::to_string(c.steps[i].srcLine) + ")\r\n";
            if (!c.steps[i].note.empty()) d += "       " + c.steps[i].note + "\r\n";
        }
        buildParams(c.params, d);
        EnableWindow(GetDlgItem(g.hwnd, ID_BTN_AUTO), FALSE);
    } else {
        const FnEntry& f = g.mf.fns[(size_t)r.index];
        g.selName = f.name;
        std::string d = f.name + "   [" + f.layer + " / tier " + f.tier + "]";
        if (f.srcLine) d += "   styleus.cpp:" + std::to_string(f.srcLine);
        d += "\r\n" + f.desc;
        if (f.dead)
            d += "\r\n※ dead code -- export 함수에서 도달 불가. 실제 파이프라인 결과에 영향 없음.";
        if (!f.needChain.empty())
            d += "\r\n※ 선행 필요: 체인 '" + f.needChain + "'.  [선행 체인 실행] 버튼을 쓰면 자동 처리된다.";
        // Tier C 함수를 단독으로 쓸 때 틀리기 쉬운 지점. DLL 매니페스트에서 온다.
        if (!f.caution.empty()) {
            std::string c = f.caution;
            // JSON 의 \n 을 편집 컨트롤용 CRLF 로
            std::string cc;
            for (char ch : c) { if (ch == '\n') cc += "\r\n"; else cc += ch; }
            d += "\r\n\r\n────────── 주의 ──────────\r\n" + cc;
        }
        buildParams(f.params, d);
        EnableWindow(GetDlgItem(g.hwnd, ID_BTN_AUTO), !f.needChain.empty());
    }
}

// --- 동작 ------------------------------------------------------------------
static void applySettings() {
    if (!g.dll.ok()) return;
    wchar_t buf[MAX_PATH] = { 0 };
    GetWindowTextW(g.outEdit, buf, MAX_PATH);
    g.dll.SIM_SetOutDir(g.dll.ctx(), A(buf).c_str());
    const int sel = (int)SendMessageW(g.dumpCombo, CB_GETCURSEL, 0, 0);
    g.dll.SIM_SetDumpLevel(g.dll.ctx(), sel < 0 ? 2 : sel);
}

static void doRun() {
    if (!g.dll.ok()) { g.lastResult = "DLL 이 로드되지 않았다."; refreshTab(); return; }
    if (g.selName.empty()) return;
    applySettings();
    const std::string kv = collectArgs();
    const int rc = g.isChain
        ? g.dll.SIM_Chain(g.dll.ctx(), g.selName.c_str(), kv.c_str(), "")
        : g.dll.SIM_Call(g.dll.ctx(), g.selName.c_str(), kv.c_str());
    afterCall(rc);
}

static void doAuto() {
    if (!g.dll.ok() || g.isChain || g.selName.empty()) return;
    const FnEntry* f = g.mf.fn(g.selName);
    if (!f || f->needChain.empty()) return;
    applySettings();
    const std::string kv = collectArgs();
    const std::string sid = g.mf.stepIdFor(f->needChain, f->name);
    const int rc = g.dll.SIM_Chain(g.dll.ctx(), f->needChain.c_str(), kv.c_str(), sid.c_str());
    afterCall(rc);
    if (sid.empty() && rc >= 0) {
        // 체인에 해당 단계가 없으면 체인만 돌리고 함수를 따로 부른다
        const int rc2 = g.dll.SIM_Call(g.dll.ctx(), f->name.c_str(), kv.c_str());
        afterCall(rc2);
    }
}

static std::string browseFile(HWND owner, const wchar_t* filter) {
    wchar_t file[MAX_PATH] = { 0 };
    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = owner;
    ofn.lpstrFilter = filter;
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    return GetOpenFileNameW(&ofn) ? A(file) : std::string();
}

static std::string browseFolder(HWND owner) {
    wchar_t path[MAX_PATH] = { 0 };
    BROWSEINFOW bi = {};
    bi.hwndOwner = owner;
    bi.lpszTitle = L"덤프 출력 폴더 선택";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    LPITEMIDLIST id = SHBrowseForFolderW(&bi);
    if (!id) return "";
    SHGetPathFromIDListW(id, path);
    CoTaskMemFree(id);
    return A(path);
}

static void doLoadDll(const std::string& pathIn) {
    std::string path = pathIn;
    if (path.empty())
        path = browseFile(g.hwnd, L"DLL (*.dll)\0*.dll\0모든 파일\0*.*\0\0");
    if (path.empty()) return;

    std::string err;
    if (!g.dll.load(path, err)) {
        g.lastResult = "[DLL 로드 실패]\r\n" + err;
        g.activeTab = 0;
        refreshTab();
        return;
    }
    if (!loadManifest(g.dll, g.mf, err)) {
        g.lastResult = "[매니페스트 로드 실패]\r\n" + err;
        refreshTab();
        return;
    }
    fillTree();
    applySettings();
    SetWindowTextW(g.hwnd, U("StyleUS 화이트박스 시뮬레이터  --  " + path).c_str());
    g.activeTab = 2;
    TabCtrl_SetCurSel(g.tab, 2);
    refreshTab();
}

// --- 레이아웃 ---------------------------------------------------------------
static void layout(int W, int H) {
    const int TOP = 34;         // 툴바
    const int TREE_W = 300;
    const int DESC_H = 180;   // 설명 + 주의사항(최대 6줄)이 스크롤 없이 들어가도록
    const int PARAM_H = 215;  // 인자 최대 8개 x 24px = 192px
    const int EXTRA_H = 52;
    const int BTN_H = 30;

    int x = TREE_W + 8;
    int w = W - x - 8;

    MoveWindow(g.tree, 4, TOP + 4, TREE_W - 4, H - TOP - 8, TRUE);

    int y = TOP + 4;
    MoveWindow(g.desc, x, y, w, DESC_H, TRUE);                 y += DESC_H + 4;
    MoveWindow(g.paramHost, x, y, w, PARAM_H, TRUE);           y += PARAM_H + 4;
    MoveWindow(g.extra, x, y, w, EXTRA_H, TRUE);               y += EXTRA_H + 4;

    const int bw = 130;
    MoveWindow(GetDlgItem(g.hwnd, ID_BTN_RUN),        x,            y, bw, BTN_H, TRUE);
    MoveWindow(GetDlgItem(g.hwnd, ID_BTN_AUTO),       x + bw + 4,   y, bw + 30, BTN_H, TRUE);
    MoveWindow(GetDlgItem(g.hwnd, ID_BTN_SLOTS),      x + 2*bw + 38, y, 90, BTN_H, TRUE);
    MoveWindow(GetDlgItem(g.hwnd, ID_BTN_CLEARSLOTS), x + 2*bw + 132, y, 100, BTN_H, TRUE);
    MoveWindow(GetDlgItem(g.hwnd, ID_BTN_CLEARLOG),   x + 2*bw + 236, y, 100, BTN_H, TRUE);
    y += BTN_H + 6;

    MoveWindow(g.tab, x, y, w, H - y - 6, TRUE);
    RECT tr = { 0, 0, w, H - y - 6 };
    TabCtrl_AdjustRect(g.tab, FALSE, &tr);
    MoveWindow(g.result, x + tr.left, y + tr.top, tr.right - tr.left, tr.bottom - tr.top, TRUE);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE: {
            g.hwnd = hwnd;
            g.fontUI = CreateFontW(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                                   OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                   DEFAULT_PITCH, L"Malgun Gothic");
            g.fontMono = CreateFontW(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                     FIXED_PITCH, L"Consolas");

            auto mk = [&](const wchar_t* cls, const wchar_t* txt, DWORD style, int id,
                          DWORD exStyle = 0) {
                HWND h = CreateWindowExW(exStyle, cls, txt, WS_CHILD | WS_VISIBLE | style,
                                         0, 0, 10, 10, hwnd, (HMENU)(INT_PTR)id, nullptr, nullptr);
                SendMessageW(h, WM_SETFONT, (WPARAM)g.fontUI, TRUE);
                return h;
            };

            // 툴바
            HWND b1 = mk(L"BUTTON", L"DLL 로드...", BS_PUSHBUTTON, ID_BTN_LOADDLL);
            MoveWindow(b1, 4, 4, 100, 26, TRUE);
            HWND lbl = CreateWindowExW(0, L"STATIC", L"출력:", WS_CHILD | WS_VISIBLE,
                                       112, 8, 34, 20, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(lbl, WM_SETFONT, (WPARAM)g.fontUI, TRUE);
            g.outEdit = mk(L"EDIT", L".\\sim_out", ES_AUTOHSCROLL, ID_OUT_EDIT, WS_EX_CLIENTEDGE);
            MoveWindow(g.outEdit, 148, 5, 300, 24, TRUE);
            HWND b2 = mk(L"BUTTON", L"...", BS_PUSHBUTTON, ID_BTN_OUTDIR);
            MoveWindow(b2, 450, 4, 26, 26, TRUE);
            HWND lbl2 = CreateWindowExW(0, L"STATIC", L"덤프 레벨:", WS_CHILD | WS_VISIBLE,
                                        486, 8, 66, 20, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(lbl2, WM_SETFONT, (WPARAM)g.fontUI, TRUE);
            g.dumpCombo = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL, ID_CMB_DUMPLEVEL);
            MoveWindow(g.dumpCombo, 554, 5, 230, 200, TRUE);
            for (const wchar_t* s : { L"0  요약만", L"1  + 스칼라",
                                      L"2  + CSV / 이미지", L"3  + 전체 버퍼 (bin/npy)" })
                SendMessageW(g.dumpCombo, CB_ADDSTRING, 0, (LPARAM)s);
            SendMessageW(g.dumpCombo, CB_SETCURSEL, 2, 0);

            // 트리
            g.tree = CreateWindowExW(WS_EX_CLIENTEDGE, WC_TREEVIEWW, L"",
                                     WS_CHILD | WS_VISIBLE | TVS_HASBUTTONS | TVS_HASLINES |
                                     TVS_LINESATROOT | TVS_SHOWSELALWAYS,
                                     0, 0, 10, 10, hwnd, (HMENU)ID_TREE, nullptr, nullptr);
            SendMessageW(g.tree, WM_SETFONT, (WPARAM)g.fontUI, TRUE);

            // 설명 / 인자 / 추가인자
            g.desc = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"DLL 을 로드하라.",
                                     WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY |
                                     ES_AUTOVSCROLL | WS_VSCROLL,
                                     0, 0, 10, 10, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(g.desc, WM_SETFONT, (WPARAM)g.fontUI, TRUE);

            g.paramHost = CreateWindowExW(WS_EX_CLIENTEDGE, L"STATIC", L"",
                                          WS_CHILD | WS_VISIBLE | SS_GRAYFRAME,
                                          0, 0, 10, 10, hwnd, nullptr, nullptr, nullptr);

            g.extra = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                                      WS_CHILD | WS_VISIBLE | ES_MULTILINE |
                                      ES_AUTOVSCROLL | WS_VSCROLL,
                                      0, 0, 10, 10, hwnd, (HMENU)ID_EXTRA, nullptr, nullptr);
            SendMessageW(g.extra, WM_SETFONT, (WPARAM)g.fontMono, TRUE);
            SendMessageW(g.extra, EM_SETCUEBANNER, TRUE,
                         (LPARAM)L"추가 인자 (key=value 를 줄바꿈으로 구분)");

            mk(L"BUTTON", L"실행", BS_PUSHBUTTON | BS_DEFPUSHBUTTON, ID_BTN_RUN);
            mk(L"BUTTON", L"선행 체인 실행 후 여기까지", BS_PUSHBUTTON, ID_BTN_AUTO);
            mk(L"BUTTON", L"슬롯 보기", BS_PUSHBUTTON, ID_BTN_SLOTS);
            mk(L"BUTTON", L"슬롯 비우기", BS_PUSHBUTTON, ID_BTN_CLEARSLOTS);
            mk(L"BUTTON", L"로그 지우기", BS_PUSHBUTTON, ID_BTN_CLEARLOG);
            EnableWindow(GetDlgItem(hwnd, ID_BTN_AUTO), FALSE);

            // 탭 + 결과창
            g.tab = CreateWindowExW(0, WC_TABCONTROLW, L"", WS_CHILD | WS_VISIBLE,
                                    0, 0, 10, 10, hwnd, (HMENU)ID_TAB, nullptr, nullptr);
            SendMessageW(g.tab, WM_SETFONT, (WPARAM)g.fontUI, TRUE);
            for (const wchar_t* s : { L"결과", L"로그 (DLL 콘솔 출력)", L"빌드 정보" }) {
                TCITEMW t = {};
                t.mask = TCIF_TEXT;
                t.pszText = const_cast<wchar_t*>(s);
                TabCtrl_InsertItem(g.tab, TabCtrl_GetItemCount(g.tab), &t);
            }
            g.result = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                                       WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY |
                                       ES_AUTOVSCROLL | ES_AUTOHSCROLL | WS_VSCROLL | WS_HSCROLL,
                                       0, 0, 10, 10, hwnd, (HMENU)ID_RESULT, nullptr, nullptr);
            SendMessageW(g.result, WM_SETFONT, (WPARAM)g.fontMono, TRUE);

            // exe 옆에 DLL 이 있으면 자동 로드
            const std::string dp = defaultDllPath();
            if (GetFileAttributesA(dp.c_str()) != INVALID_FILE_ATTRIBUTES) doLoadDll(dp);
            return 0;
        }

        case WM_SIZE:
            layout(LOWORD(lp), HIWORD(lp));
            return 0;

        case WM_GETMINMAXINFO: {
            auto* mm = (MINMAXINFO*)lp;
            mm->ptMinTrackSize.x = 1100;
            mm->ptMinTrackSize.y = 760;
            return 0;
        }

        case WM_NOTIFY: {
            auto* nh = (NMHDR*)lp;
            if (nh->idFrom == ID_TREE && nh->code == TVN_SELCHANGEDW) {
                onSelect(((NMTREEVIEWW*)lp)->itemNew.hItem);
                return 0;
            }
            if (nh->idFrom == ID_TAB && nh->code == TCN_SELCHANGE) {
                g.activeTab = TabCtrl_GetCurSel(g.tab);
                refreshTab();
                return 0;
            }
            break;
        }

        case WM_COMMAND: {
            const int id = LOWORD(wp);
            if (id >= ID_BROWSE_BASE && id < ID_BROWSE_BASE + 100) {
                const size_t i = (size_t)(id - ID_BROWSE_BASE);
                if (i < g.paramEdits.size()) {
                    const std::string p = browseFile(hwnd,
                        L"DICOM (*.dcm)\0*.dcm\0RAW (*.raw)\0*.raw\0모든 파일\0*.*\0\0");
                    if (!p.empty()) SetWindowTextW(g.paramEdits[i], U(p).c_str());
                }
                return 0;
            }
            switch (id) {
                case ID_BTN_LOADDLL: doLoadDll(""); return 0;
                case ID_BTN_OUTDIR: {
                    const std::string d = browseFolder(hwnd);
                    if (!d.empty()) SetWindowTextW(g.outEdit, U(d).c_str());
                    return 0;
                }
                case ID_BTN_RUN:  doRun();  return 0;
                case ID_BTN_AUTO: doAuto(); return 0;
                case ID_BTN_SLOTS:
                    if (g.dll.ok()) afterCall(g.dll.SIM_ListSlots(g.dll.ctx()));
                    return 0;
                case ID_BTN_CLEARSLOTS:
                    if (g.dll.ok()) {
                        g.dll.SIM_ClearSlots(g.dll.ctx());
                        afterCall(g.dll.SIM_ListSlots(g.dll.ctx()));
                    }
                    return 0;
                case ID_BTN_CLEARLOG:
                    if (g.dll.ok()) {
                        g.dll.SIM_ClearLog(g.dll.ctx());
                        g.lastLog.clear();
                        g.activeTab = 1;
                        TabCtrl_SetCurSel(g.tab, 1);
                        refreshTab();
                    }
                    return 0;
            }
            break;
        }

        case WM_DESTROY:
            g.dll.unload();
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

static int runGui(HINSTANCE hInst) {
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_TREEVIEW_CLASSES | ICC_TAB_CLASSES |
                                              ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"StyleUSSimWnd";
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName,
                                L"StyleUS 화이트박스 시뮬레이터",
                                WS_OVERLAPPEDWINDOW,
                                CW_USEDEFAULT, CW_USEDEFAULT, 1320, 880,
                                nullptr, nullptr, hInst, nullptr);
    if (!hwnd) return 1;
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (IsDialogMessageW(hwnd, &msg)) continue;
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return 0;
}

// ---------------------------------------------------------------------------
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int) {
    int argc = 0;
    LPWSTR* argvW = CommandLineToArgvW(GetCommandLineW(), &argc);
    std::vector<std::string> args;
    for (int i = 1; i < argc; ++i) args.push_back(A(argvW[i]));
    LocalFree(argvW);

    const bool cli = !args.empty() && (args[0] == "--cli" || args[0] == "-c" ||
                                       args[0] == "--help" || args[0] == "-h");
    if (!cli) return runGui(hInst);

    // 부모 콘솔에 붙는다. 없으면 새로 만든다(더블클릭 실행 대비).
    if (!AttachConsole(ATTACH_PARENT_PROCESS)) AllocConsole();
    SetConsoleOutputCP(CP_UTF8);
    FILE* fp = nullptr;
    freopen_s(&fp, "CONOUT$", "w", stdout);
    freopen_s(&fp, "CONOUT$", "w", stderr);

    if (args[0] == "--help" || args[0] == "-h") return cliUsage();
    args.erase(args.begin());
    const int rc = runCli(args);
    fflush(stdout);
    return rc;
}
