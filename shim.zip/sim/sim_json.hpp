// ============================================================================
//  sim_json.hpp -- 의존성 없는 최소 JSON 리더 + 프리티 프린터 (exe 전용)
// ----------------------------------------------------------------------------
//  UI 는 DLL 이 내보내는 매니페스트 JSON 을 읽어 함수 목록과 인자 폼을 동적으로
//  만든다. 그래서 파서가 필요하다. 외부 라이브러리를 쓰지 않는 이유는 이 exe 가
//  Build Tools 만으로 빌드되어야 하기 때문이다.
//
//  지원 범위: object / array / string / number / true / false / null.
//  DLL 이 만든 JSON 만 읽으므로 이 정도면 충분하다.
//  (JsonW 는 NaN/Infinity 를 문자열로 escape 하므로 숫자 파싱이 깨지지 않는다)
// ============================================================================
#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <cstdlib>
#include <cstdio>
#include <cctype>

namespace sj {

struct Value;
using ValuePtr = std::shared_ptr<Value>;

enum class Type { Null, Bool, Number, String, Array, Object };

struct Value {
    Type type = Type::Null;
    bool b = false;
    double num = 0;
    std::string str;
    std::vector<ValuePtr> arr;
    std::vector<std::pair<std::string, ValuePtr>> obj;   // 순서 보존

    const Value* find(const std::string& k) const {
        if (type != Type::Object) return nullptr;
        for (const auto& kv : obj) if (kv.first == k) return kv.second.get();
        return nullptr;
    }
    std::string s(const std::string& k, const std::string& def = "") const {
        const Value* v = find(k);
        if (!v) return def;
        if (v->type == Type::String) return v->str;
        if (v->type == Type::Bool)   return v->b ? "true" : "false";
        if (v->type == Type::Number) {
            char buf[64];
            if (v->num == (long long)v->num) snprintf(buf, sizeof(buf), "%lld", (long long)v->num);
            else snprintf(buf, sizeof(buf), "%g", v->num);
            return buf;
        }
        return def;
    }
    bool boolean(const std::string& k, bool def = false) const {
        const Value* v = find(k);
        if (!v) return def;
        if (v->type == Type::Bool) return v->b;
        if (v->type == Type::Number) return v->num != 0;
        return def;
    }
    int integer(const std::string& k, int def = 0) const {
        const Value* v = find(k);
        return (v && v->type == Type::Number) ? (int)v->num : def;
    }
};

class Parser {
public:
    static ValuePtr parse(const std::string& text) {
        Parser p(text);
        p.ws();
        ValuePtr v = p.value();
        return v;
    }

private:
    explicit Parser(const std::string& t) : t_(t) {}

    void ws() { while (i_ < t_.size() && (t_[i_] == ' ' || t_[i_] == '\t' || t_[i_] == '\n' || t_[i_] == '\r')) ++i_; }

    ValuePtr value() {
        ws();
        if (i_ >= t_.size()) return nullptr;
        switch (t_[i_]) {
            case '{': return object();
            case '[': return array();
            case '"': { auto v = std::make_shared<Value>(); v->type = Type::String; v->str = string(); return v; }
            case 't': i_ += 4; { auto v = std::make_shared<Value>(); v->type = Type::Bool; v->b = true;  return v; }
            case 'f': i_ += 5; { auto v = std::make_shared<Value>(); v->type = Type::Bool; v->b = false; return v; }
            case 'n': i_ += 4; return std::make_shared<Value>();
            default:  return number();
        }
    }

    ValuePtr object() {
        auto v = std::make_shared<Value>();
        v->type = Type::Object;
        ++i_;  // '{'
        ws();
        if (i_ < t_.size() && t_[i_] == '}') { ++i_; return v; }
        while (i_ < t_.size()) {
            ws();
            if (i_ >= t_.size() || t_[i_] != '"') break;
            std::string k = string();
            ws();
            if (i_ < t_.size() && t_[i_] == ':') ++i_;
            ValuePtr val = value();
            v->obj.emplace_back(k, val ? val : std::make_shared<Value>());
            ws();
            if (i_ < t_.size() && t_[i_] == ',') { ++i_; continue; }
            if (i_ < t_.size() && t_[i_] == '}') { ++i_; break; }
            break;
        }
        return v;
    }

    ValuePtr array() {
        auto v = std::make_shared<Value>();
        v->type = Type::Array;
        ++i_;  // '['
        ws();
        if (i_ < t_.size() && t_[i_] == ']') { ++i_; return v; }
        while (i_ < t_.size()) {
            ValuePtr e = value();
            v->arr.push_back(e ? e : std::make_shared<Value>());
            ws();
            if (i_ < t_.size() && t_[i_] == ',') { ++i_; continue; }
            if (i_ < t_.size() && t_[i_] == ']') { ++i_; break; }
            break;
        }
        return v;
    }

    std::string string() {
        std::string o;
        ++i_;  // 여는 따옴표
        while (i_ < t_.size() && t_[i_] != '"') {
            if (t_[i_] == '\\' && i_ + 1 < t_.size()) {
                ++i_;
                switch (t_[i_]) {
                    case 'n': o += '\n'; break;
                    case 't': o += '\t'; break;
                    case 'r': o += '\r'; break;
                    case 'b': o += '\b'; break;
                    case 'f': o += '\f'; break;
                    case '/': o += '/';  break;
                    case '"': o += '"';  break;
                    case '\\': o += '\\'; break;
                    case 'u': {
                        if (i_ + 4 < t_.size()) {
                            unsigned cp = (unsigned)strtoul(t_.substr(i_ + 1, 4).c_str(), nullptr, 16);
                            i_ += 4;
                            // UTF-8 인코딩 (BMP 범위만)
                            if (cp < 0x80) o += (char)cp;
                            else if (cp < 0x800) {
                                o += (char)(0xC0 | (cp >> 6));
                                o += (char)(0x80 | (cp & 0x3F));
                            } else {
                                o += (char)(0xE0 | (cp >> 12));
                                o += (char)(0x80 | ((cp >> 6) & 0x3F));
                                o += (char)(0x80 | (cp & 0x3F));
                            }
                        }
                        break;
                    }
                    default: o += t_[i_];
                }
                ++i_;
            } else {
                o += t_[i_++];
            }
        }
        if (i_ < t_.size()) ++i_;  // 닫는 따옴표
        return o;
    }

    ValuePtr number() {
        auto v = std::make_shared<Value>();
        v->type = Type::Number;
        size_t st = i_;
        while (i_ < t_.size() &&
               (isdigit((unsigned char)t_[i_]) || t_[i_] == '-' || t_[i_] == '+' ||
                t_[i_] == '.' || t_[i_] == 'e' || t_[i_] == 'E')) ++i_;
        if (i_ == st) { ++i_; v->type = Type::Null; return v; }
        v->num = atof(t_.substr(st, i_ - st).c_str());
        return v;
    }

    const std::string& t_;
    size_t i_ = 0;
};

// ---------------------------------------------------------------------------
// 프리티 프린터
//   결과 JSON 을 사람이 읽을 형태로. 문자열 안의 중괄호를 들여쓰기로 오인하지
//   않도록 문자열 상태를 추적한다.
// ---------------------------------------------------------------------------
inline std::string pretty(const std::string& in, int indentWidth = 2) {
    std::string o;
    o.reserve(in.size() * 2);
    int depth = 0;
    bool inStr = false, esc = false;
    auto nl = [&](int d) {
        o += "\r\n";
        o.append((size_t)d * indentWidth, ' ');
    };
    for (size_t i = 0; i < in.size(); ++i) {
        const char c = in[i];
        if (inStr) {
            o += c;
            if (esc)            esc = false;
            else if (c == '\\') esc = true;
            else if (c == '"')  inStr = false;
            continue;
        }
        switch (c) {
            case '"': inStr = true; o += c; break;
            case '{': case '[': {
                // 빈 객체/배열은 한 줄로
                size_t k = i + 1;
                while (k < in.size() && (in[k] == ' ' || in[k] == '\n')) ++k;
                if (k < in.size() && (in[k] == '}' || in[k] == ']')) {
                    o += c; o += in[k]; i = k; break;
                }
                o += c; ++depth; nl(depth);
                break;
            }
            case '}': case ']':
                --depth; nl(depth); o += c;
                break;
            case ',':
                o += c; nl(depth);
                break;
            case ':':
                o += ": ";
                break;
            default:
                o += c;
        }
    }
    return o;
}

}  // namespace sj
