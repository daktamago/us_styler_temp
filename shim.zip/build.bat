@echo off
rem ===========================================================================
rem  build.bat -- StyleUS 시뮬레이터 원클릭 빌드
rem ---------------------------------------------------------------------------
rem  필요한 것
rem    · Visual Studio Build Tools 2022 (C++ 워크로드 + Windows SDK)
rem    · CMake (Build Tools 에 동봉된 것이면 충분)
rem    · Python 3 (스테이징/검사용)
rem
rem  사용
rem    build.bat                 -> Debug 빌드
rem    build.bat Release         -> Release 빌드
rem    build.bat Debug clean     -> 빌드 폴더를 지우고 처음부터
rem ===========================================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set CFG=%1
if "%CFG%"=="" set CFG=Debug
set CLEAN=%2

echo.
echo === StyleUS 시뮬레이터 빌드 (%CFG%) ===
echo.

rem --- MSVC 환경 진입 --------------------------------------------------------
where cl.exe >nul 2>nul
if errorlevel 1 (
    echo [1/4] MSVC 환경 진입...
    set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
    if not exist "!VSWHERE!" (
        echo.
        echo   [오류] Visual Studio Build Tools 를 찾을 수 없다.
        echo.
        echo   설치 방법:
        echo     winget install --id Microsoft.VisualStudio.2022.BuildTools --override ^
"--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
        echo.
        echo   IDE 는 필요 없다. VS Code + C/C++ 확장이면 편집까지 충분하다.
        exit /b 1
    )
    for /f "usebackq tokens=*" %%i in (`"!VSWHERE!" -latest -products * ^
-requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set VSPATH=%%i
    if "!VSPATH!"=="" (
        echo   [오류] C++ 도구 세트가 설치되어 있지 않다.
        exit /b 1
    )
    call "!VSPATH!\VC\Auxiliary\Build\vcvars64.bat" >nul
    if errorlevel 1 ( echo   [오류] vcvars64.bat 실패 & exit /b 1 )
) else (
    echo [1/4] MSVC 환경 확인됨
)

rem --- 소스 스테이징 ---------------------------------------------------------
echo [2/4] 원본 스테이징 + 드리프트 검사...
set PY=python
where %PY% >nul 2>nul || set PY=py
%PY% tools\prepare_source.py --root .
if errorlevel 1 (
    echo.
    echo   [오류] 스테이징 실패. 위 메시지를 확인하라.
    exit /b 1
)

rem --- CMake 구성 ------------------------------------------------------------
if /i "%CLEAN%"=="clean" (
    echo       build 폴더 정리...
    if exist build rmdir /s /q build
)
echo [3/4] CMake 구성...
cmake -S . -B build -G "Ninja Multi-Config" >nul 2>nul
if errorlevel 1 (
    echo       Ninja 없음 -> Visual Studio 제너레이터로 전환
    cmake -S . -B build -G "Visual Studio 17 2022" -A x64
    if errorlevel 1 ( echo   [오류] CMake 구성 실패 & exit /b 1 )
)

rem --- 빌드 -----------------------------------------------------------------
echo [4/4] 빌드...
cmake --build build --config %CFG%
if errorlevel 1 (
    echo.
    echo   [오류] 빌드 실패.
    echo.
    echo   LNK1104: cannot open file '..\lib\onnxruntime.lib' 이 나오면
    echo     styleus.cpp:39 의 #pragma comment(lib, "../lib/onnxruntime.lib") 때문이다.
    echo     tools\prepare_source.py 가 lib\onnxruntime.lib 를 만들었는지 확인하라.
    exit /b 1
)

echo.
echo === 완료 ===
for /f "delims=" %%f in ('dir /s /b build\styleus_sim.exe 2^>nul') do echo   exe: %%f
for /f "delims=" %%f in ('dir /s /b build\StyleUS_sim.dll 2^>nul') do echo   dll: %%f
echo.
echo   자체 검증:  cmake --build build --config %CFG% --target selftest
echo   GUI 실행 :  위 exe 를 그냥 실행
echo.
endlocal
