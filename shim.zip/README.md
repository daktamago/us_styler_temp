# StyleUS 화이트박스 시뮬레이터

`styleus.cpp` 내부 함수 43개와, `RunStyleUSInference()` 안에 인라인으로 박혀 있는
전처리 12단계를 **개별로 호출하고 중간값을 덤프**하는 도구.

원본 소스는 한 글자도 고치지 않는다.

---

## 1. 빠른 시작 (빌드 머신)

```bat
build.bat Debug
```

빌드가 끝나면:

```bat
cmake --build build --config Debug --target selftest
```

`selftest` 는 DICOM/RAW 자산이 하나도 없어도 돌아간다. 40여 개 항목을 검사하며,
md 문서의 계약(`sizeof(RSDMR)==256`, 고정상수 산식, range 표)이 실제 빌드와
일치하는지 못 박는다.

GUI 는 `build/Debug/styleus_sim.exe` 를 그냥 실행.

### 필요한 것

| 항목 | 비고 |
|---|---|
| Visual Studio **Build Tools 2022** (C++ 워크로드 + Windows SDK) | IDE 불필요. `winget install --id Microsoft.VisualStudio.2022.BuildTools --override "--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"` |
| CMake | Build Tools 동봉본으로 충분 |
| Python 3 | 스테이징/검사용 |

**MinGW / clang(비-MSVC)은 지원하지 않는다.** `styleus.cpp` 가 `sprintf_s`,
`EXTERN_C IMAGE_DOS_HEADER __ImageBase`, `#pragma comment(lib, ...)` 등 MSVC 전용
구문을 쓰고, 원본 DLL 이 MSVC STL 로 빌드되어 있다. 다른 컴파일러로 만든 사본은
부동소수·컨테이너 동작이 미세하게 달라져 검증 도구로서의 의미가 없어진다.

---

## 2. 구조

```
dll_simul/
├─ styleus.cpp                  원본 (무수정)
├─ styleus.h, SDMR/DllMain.h    원본 (손상됨 -- 아래 §6 참고)
│
├─ tools/
│   ├─ prepare_source.py        스테이징 + 드리프트 검사 + 호출그래프 분석
│   └─ selftest.py              빌드 후 CLI 자체 검증
│
├─ shim/                        → StyleUS_sim.dll
│   ├─ sim_abi.h                exe ↔ dll 경계 (C-ABI 만)
│   ├─ sim_dump.hpp             JSON 빌더 / 슬롯 / PGM·CSV·NPY 라이터
│   ├─ styleus_shim.cpp         원본을 유닛 빌드로 품고 ABI 구현
│   ├─ shim_functions.inc       원본 함수 43개 래퍼
│   ├─ shim_stages.inc          S1~S12 인라인 단계 등가 재현
│   ├─ shim_chains.inc          사전 정의 체인 7개
│   └─ include/                 복구된 헤더 (원본 대체용)
│
├─ sim/                         → styleus_sim.exe
│   ├─ main.cpp                 Win32 GUI + CLI (같은 코어 공유)
│   ├─ sim_dll.hpp              LoadLibrary 래퍼
│   └─ sim_json.hpp             최소 JSON 리더 + 프리티 프린터
│
├─ build_src/                   prepare_source.py 가 만드는 스테이징 (자동 생성)
└─ CMakeLists.txt, build.bat
```

### 왜 "static 제거" 가 아니라 "유닛 빌드" 인가

당초 안은 *원본 사본을 만들어 `static` 을 전부 제거한 뒤 DLL 빌드* 였다.
두 가지 이유로 채택하지 않았다.

1. **`static` 제거만으로는 아무것도 열리지 않는다.**
   외부 링크가 열릴 뿐 DLL export table 에는 올라가지 않아 `GetProcAddress`
   로 잡을 수 없다. 실제로 L1 함수 10개(`GetMyDllDirectory` 등)는 원본에서
   **이미 non-static 인데도** 호출이 불가능하다. `__declspec(dllexport)` 가
   반드시 추가로 필요하다.

2. **정규식 `static` 제거는 동작을 바꾼다.**
   함수 내부의 지역 `static` 까지 지워진다.
   `styleus.cpp:122` 로그 파일 경로 캐시, `:707` Lanczos 상수표,
   `:1482` 피팅 시드 배열이 그렇다. 검증 도구가 검증 대상을 변형시키면
   결과를 믿을 수 없다.

그래서 `styleus_shim.cpp` 가 원본 `.cpp` 를 통째로 `#include` 한다(유닛 빌드).
같은 번역 단위에 들어오므로 `static` 함수 전부가 보이고, 바깥으로는
`extern "C"` C-ABI 래퍼만 내보낸다. 이름 맹글링·STL 의 DLL 경계 통과·
exe/dll CRT 불일치 문제가 한 번에 사라진다.

> 참고용으로 `python tools/prepare_source.py --mode strip` 을 주면 당초 안
> (static 제거본)도 생성한다. 지역 static / `static_cast` 는 건드리지 않도록
> 규칙을 좁혔고, 보존 여부를 자동 확인한다. 기본 경로는 아니다.

---

## 3. 무엇을 볼 수 있는가

### 원본 함수 43개

| 계층 | 개수 | 내용 |
|---|---|---|
| L1 | 10 | 경로 탐색 / 로그 |
| L2 | 6 | DICOM 파서 |
| L3 | 12 | 영상 처리 |
| L4 | 10 | 부채꼴 기하 추정 |
| L5 | 4 | 파이프라인 통합 |
| — | +1 | `Aborted` (md 목록 누락분) |

> md 문서의 계층별 개수(10/6/11/8/4)는 틀렸다. 실제는 10/6/12/10/4 이며
> 번호 1~42 자체는 맞다.

### S1~S12 인라인 단계

`RunStyleUSInference()` 는 790줄 단일 함수이고, 모델 입력을 만드는 전처리
12단계가 전부 함수가 아니라 인라인 코드다. **함수를 아무리 export 해도 열리지
않는다.** 그런데 소스 리뷰가 지목한 High 등급 문제가 거기 몰려 있다.

`shim_stages.inc` 가 이 구간을 등가 재현한다. 각 단계마다 원본 라인 번호를
주석으로 못 박고, 변수명(`w_idx`, `x_ratio`, `pad_w_idx` …)까지 그대로 유지한다.

> ⚠ 의도적 차이 1건: **S1 의 경계 미검사 쓰기는 재현하되 실행하지 않는다.**
> 검사 도구가 자기 힙을 밟고 죽으면 리포트를 못 남긴다. 대신 어떤 인덱스가
> 범위를 벗어나는지 정확히 세어서 `out_of_bounds_writes` 로 보고한다.
> 원본은 그 지점에서 실제로 쓴다.

---

## 4. 사용법

### GUI

1. `[DLL 로드...]` — exe 옆에 `StyleUS_sim.dll` 이 있으면 자동 로드된다.
2. 왼쪽 트리에서 함수 선택. 배지가 붙는다.
   - `[단독]` 선행 없이 바로 실행 가능
   - `[체인:mask]` 선행 체인 필요
   - `[dead]` 원본에서 도달 불가
3. 인자 폼이 자동으로 만들어진다. 비워두면 DLL 기본값이 쓰인다.
4. `[실행]` 또는 `[선행 체인 실행 후 여기까지]`.

인자 폼은 **DLL 매니페스트에서 만들어진다.** DLL 을 고쳐도 exe 를 다시 빌드할
필요가 없다.

### CLI

GUI 와 완전히 같은 코어를 쓴다. 회귀 검증 자동화용.

```bat
styleus_sim.exe --cli info
styleus_sim.exe --cli list
styleus_sim.exe --cli chains

:: ONNX 모델도 자산도 없이 검증 가능한 것들
styleus_sim.exe --cli call IsLongFormVR
styleus_sim.exe --cli call S4_PostCV  raw37=0.5,0.5,...
styleus_sim.exe --cli call S11_PackRSDMR pred37=...
styleus_sim.exe --cli call S12_WriteIni lqs7=50,40,9,45,-15,0.0000123,0.0000456

:: 마스크 체인 전체 (각 단계 PGM 덤프)
styleus_sim.exe --cli chain mask path=C:\dump\specialist_mode_assets\dicom\style_01.dcm --dump-level 2

:: 특정 함수까지만
styleus_sim.exe --cli chain mask path=...\style_01.dcm --stop-after FloodFillMask

:: 선행 체인 자동 처리
styleus_sim.exe --cli auto FitSector path=...\style_01.dcm

:: RAW 파일에서 바로 CV 텐서까지
styleus_sim.exe --cli load cv_raw raw_i16 style_01_x528_y177_CV.raw width=528 height=177
styleus_sim.exe --cli chain cv_tensors --dump-level 3
```

`--dump-level 3` 이면 `.npy` 로 떨어진다 → 학습측 Python 전처리와 bit-exact 대조.

### 체인 7개

| 체인 | 내용 |
|---|---|
| `load_dicom` | DICOM 1장 → `image` |
| `mask` | AnalyzeDicom 의 마스크 생성 순서 재현 (9단계) + 섹터 오버레이 |
| `spline_path` | 확대 → B-spline 계수 → 3차 보간 (1채널 전용) |
| `dicom_to_polar` | 기하 추정 → 역스캔변환 → CV/LQS 픽셀 |
| `cv_tensors` | S1·S2·S3 |
| `lqs_tensors` | S5~S9 |
| `post_and_pack` | S4·S11·S10·S12 |

`mask` 체인은 실행 후 `expected_geom_from_sector` 를 함께 낸다. 같은 파일로
`AnalyzeDicom` 을 단독 호출한 결과와 대조하면 **체인 재현이 맞는지 즉시 확인**된다.

---

## 5. 경로에 대해

경로 지정 UI 는 **넣지 않았다.** 화이트박스 호출은 파일 경로를 인자로 직접
넘기므로 원본의 경로 탐색 로직을 거치지 않는다.

경로 탐색이 관여하는 함수는 `SearchFileInDir` / `FindRawFileAndParseSize` /
`FindDicomFile` 셋뿐인데, 이건 **탐색 순서를 관찰하는 것이 목적**이라 override
를 걸면 검증 자체가 무의미해진다. 대신 이 세 함수는 실행 시
후보 5개 디렉터리와 매칭 순번(`search_dirs[].rank/exists/matched`), 그리고
현재 CWD·DLL 폴더를 함께 리포트한다.

`<dllDir>` 기준 상대경로를 바꿔보고 싶으면 **DLL 사본을 원하는 폴더에 두고
그 경로로 로드**하면 된다 (`--dll <path>`). 후킹 같은 우회 기법은 쓰지 않는다.

---

## 6. 알려진 선행 조건

### 손상된 헤더

`styleus.h` 와 `SDMR/DllMain.h` 는 붙여넣기 과정에서 토큰 사이 단일 공백이
소실되어 **컴파일 불가** 상태다.

```
styleus.h:3     #ifdefSTYLEUS_EXPORTS
styleus.h:26    STYLEUS_API voidRunStyleUSInference(
DllMain.h       typedefstructRSDMR / #pragmaonce / #include"CommonDef.h"   (34곳)
```

`styleus.cpp` 는 멀쩡하다(같은 패턴 0건).

`shim/include/` 에 **공백만 복원한 복구본**을 두었다. 선언 내용은 원본과 동일하다.
`prepare_source.py` 가 이것을 `build_src/` 에 배치해서, 따옴표 include 가
손상된 루트 헤더 대신 복구본을 집게 만든다.

> **사내 원본 헤더를 다시 확보하면 `shim/include/` 의 것을 교체하라.**

### 없는 헤더

`SDMR/DllMain.h` 가 `CommonDef.h` / `SLibUtils.h` 를 include 하는데 둘 다 없다.
`styleus.cpp` 는 `RSDMR` 하나만 쓰고 `RSDMR` 은 자기완결적이므로 최소 stub 으로
대체했다 (`MAX_LEVEL` 만 정의). `PARAMUSDLL` 은 이 DLL 에서 쓰이지 않으므로
stub 값이 결과에 영향을 주지 않는다.

### 원본 DLL

`styleus.dll` 은 **불필요하다.** 사본은 손으로 모사한 것이 아니라 **원본과
바이트 단위로 동일한 소스를 컴파일한 것**이므로, 알고리즘 층위에서는 원본과
같다고 보면 된다.

md 발견사항 15건과 S1~S12 검증 항목 중 **부동소수 하위 비트에 민감한 것은
하나도 없다.** 전부 인덱스 계산 / 제어 흐름 / 문자열 파싱 / 상수값 / 구조체
레이아웃 문제이고, 컴파일러가 바뀌어도 결과가 바뀌지 않는다.
(x64 MSVC 는 기본 `/fp:precise` + SSE2 스칼라라 x87 80bit 문제도, 재결합
최적화도 없다. 차이가 날 수 있는 건 CRT 초월함수 `atan2`/`tan`/`sqrt` 의
마지막 비트 정도다.)

원본 DLL 이 필요한 경우는 좁고, 둘 다 정밀도 문제가 아니라 형상/빌드 구성
문제다. **착수 전제가 아니라 마지막 체크리스트 항목이다.**

| 확인할 것 | 방법 |
|---|---|
| 출하본이 이 버전의 소스로 빌드됐는가 | 같은 DICOM 으로 원본/사본을 각각 1회 실행해 `style_result.ini` · `.rsdmr` 비교. 함수 단위로 할 일이 아니다 |
| 배포 형태가 Debug 인가 (md #13) | 원본 `.dll` 에 `dumpbin /imports`. 시뮬레이터와 무관 |

> 예외 1건: `FitSector` 의 IoU 가 임계값 0.90 바로 근처(0.88~0.92)에 걸리는
> 입력은 빌드 환경에 따라 성공/실패가 갈릴 수 있다. IoU 자체는 정수 카운트
> 나눗셈이라 결정적이지만, 탐색 시작점이 `atan2`(styleus.cpp:1490)에서 나오고
> 1 ULP 차이가 좌표하강의 `v > best` 비교를 뒤집어 다른 국소해로 갈 수 있다.
>
> 이것은 "원본 DLL 이 필요하다" 는 결론이 아니라 **더 강한 결론**으로 이어진다 —
> 그런 입력은 애초에 마진이 없으므로 임계값 정책을 손봐야 한다. 그리고 이
> 판정은 `SectorIoU` 파라미터 스윕으로 시뮬레이터가 혼자 내릴 수 있다
> (경계 구간 경고는 이미 구현되어 있다).

---

## 7. 문서 정정 사항

`dll시뮬레이터_제작개요.md` 대비 확정/정정된 것들. 전부 소스에서 직접 확인했다.

| # | 항목 | 결과 |
|---|---|---|
| 1 | `sizeof(RSDMR)` (md W1 / 발견사항 #5) | **256 확정.** 전 멤버 4바이트 정렬, 패딩 0. `.rsdmr` = 1288 bytes. `static_assert` 로 빌드에 못 박음 |
| 2 | 계층별 함수 개수 | md 의 10/6/11/8/4 는 틀림. 실제 **10/6/12/10/4**. 번호 1~42 는 맞음 |
| 3 | `Aborted()` | md 목록 누락. 취소 검증 대상이므로 43번째로 추가 |
| 4 | dead code | **6개.** `WriteStyleUSLogW`, `CastToUint8Truncate`, `FindHighestCoordinates`, `CalculateAngleWithVertical`, `FindRadius` (호출처 0) + `TraceOuterContour` (dead 함수에서만 호출 → 전이적 dead). md 가 "가장 취약, 최우선" 이라 한 L4 10개 중 4개가 여기 해당 |
| 5 | 실제 기하 추정 경로 | `AnalyzeDicom` 은 `FindRobustSeed → FloodFillMask → FitSector` 로 직행. 기하 추정 전체가 **`FitSector` 하나**에 걸려 있음 |
| 6 | 발견사항 #12 (`lqs_hist ÷2048`) | **md 계산이 틀림.** 이 히스토그램은 확률질량이 아니라 **밀도(PDF)** 다. `sum × bin_width = 1.0` 이 되므로 ÷2048 은 올바른 정규화. md 의 "≈0.256" 은 오산. **진짜 문제는 따로 있다** — 1.0 을 넘는 픽셀(원본 >150)이 통째로 버려져 적분값이 1.0 미만으로 내려간다. `S9_LqsHist` 가 `dropped_out_of_0_1` 로 카운트한다 |
| 7 | CV/LQS 히스토그램 정규화 | **비대칭.** CV(S2)는 `count/total_pixels` → 합 1.0 (확률질량), LQS(S9)는 밀도. 학습측과 대조 필수 |
| 8 | CV 히스토그램 분모 | md 미언급. `val / **2040.0f** * 255.0f` 이다. `ToCvRawPixelsF` 의 clamp 상한은 2047 이라 상단이 bin 255 로 몰린다 |
| 9 | `RSDMR_Z` 필드 수 | md §4.2 는 4개로 적었으나 실제 **5개**. `int ContrastCurve;` 가 `fZoomEffectGain` 과 `iReserved` 사이에 있고, 원본이 세팅하지 않아 0 으로 남는다 |
| 10 | `ThresholdBinary` 적용 시점 | **확대 전 원본 해상도.** `ResizeLanczos4`(×3)는 마스크 확정 **이후**. 순서를 뒤집으면 결과가 달라진다 |
| 11 | `SampleCubicSpline` / `SampleBilinear` | **배타적 경로.** 1채널이면 spline, 3채널이면 bilinear. 원본도 1채널일 때만 `SplineFilter2D` 를 호출한다 |

---

## 8. 아직 안 한 것

| 항목 | 왜 |
|---|---|
| 블랙박스 `run` (실 DLL 전체 실행) | 원본 `styleus.dll` 이 워크스페이스에 없다 |
| 취소 / 스레드 / 에러주입 매트릭스 (md §5) | 화이트박스 덤프를 먼저 확정한 뒤 착수. ABI 에 `SIM_SetForceExit` 는 이미 열어 두었다 |
| ONNX 추론 단계 | 모델 파일(`styleus_CV.onnx` / `styleus_LQS.onnx`)이 없다. 단 S4·S10·S11·S12 는 **모델 없이 값만 넣어** 이미 검증 가능하다 |
| 골든 데이터 / HTML 리포트 (md §7, §9) | 정상 샘플 확보 후 |

## 9. 이 워크스테이션에서의 검증 범위

Visual Studio Build Tools 가 설치되어 있지 않아 **빌드·실행은 수행하지 못했다.**
수행한 것은 다음과 같다.

- `tools/prepare_source.py` 실행 및 결과 확인 (함수 43개 위치, S1~S12 앵커,
  계약 상수 9개, 호출그래프 도달성 분석)
- 원본 소스 직접 독해로 시그니처·라인·상수 확인
- `sizeof(RSDMR)` 수기 계산 검증

C++ 코드는 **컴파일 검증되지 않았다.** 첫 빌드에서 오류가 나오면 알려주면
바로 잡겠다.
