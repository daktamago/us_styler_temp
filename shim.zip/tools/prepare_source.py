#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prepare_source.py -- StyleUS 화이트박스 시뮬레이터용 소스 스테이징 & 드리프트 검사

무엇을 하는가
--------------
1. styleus.cpp 를 build_src/ 로 **바이트 단위 그대로** 복사한다 (SHA-256 검증).
2. 복구된 헤더(shim/include/*)를 build_src/ 에 함께 배치한다.
   -> 따옴표 include 가 손상된 루트 헤더 대신 복구본을 집게 만든다.
3. 원본 안에 42개 대상 함수가 예상 위치/형태로 살아있는지 검사한다(드리프트 검사).
   원본이 바뀌면 여기서 먼저 걸린다.
4. onnxruntime.lib 를 <root>/lib/ 로 복사한다.
   styleus.cpp:39 의 #pragma comment(lib, "../lib/onnxruntime.lib") 를 만족시키기 위함.
5. functions.json (문서용 매니페스트)를 만든다.

왜 "static 제거" 를 하지 않는가
--------------------------------
당초 안은 "사본 cpp 에서 static 을 전부 제거" 였다. 두 가지 이유로 채택하지 않았다.

  (1) static 제거는 외부 링크만 열 뿐 DLL export 를 만들지 않는다. GetProcAddress
      로 잡을 수 없다. 실제로 L1 함수 10개는 원본에서 이미 non-static 인데도
      호출이 불가능하다. __declspec(dllexport) 가 별도로 필요하다.
  (2) 정규식으로 static 을 지우면 함수 내부의 지역 static 까지 지워져 동작이 바뀐다.
        styleus.cpp:122  static std::string cachedLogFilePath  <- 로그 파일 1개 유지
        styleus.cpp:707  static const double cs[8][2]          <- Lanczos 상수표
        styleus.cpp:1482 static const double kStarts[5]        <- 피팅 시드
      검증 도구가 검증 대상을 변형시키면 결과를 믿을 수 없다.

대신 shim/styleus_shim.cpp 이 이 사본을 통째로 #include 한다(유닛 빌드).
같은 번역 단위에 들어오므로 static 함수 전부가 보이고, 원본은 무수정이다.

--mode strip 을 주면 당초 안(static 제거본)도 참고용으로 생성한다.
지역 static 과 static_cast 는 건드리지 않도록 규칙을 좁혔지만, 기본 경로가 아니다.

사용법
------
    python tools/prepare_source.py
    python tools/prepare_source.py --root . --mode strip
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

# 콘솔 인코딩 고정 (Git Bash/cmd 의 cp949 에서 한글이 깨지는 것을 막는다)
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------------------------------------------------------------------------
# 대상 함수 인벤토리
#   (이름, 계층, 기대 라인, static 여부, dead code 여부, 반환형 조각)
#   기대 라인은 참고용이다. 실제 검사는 이름+괄호 패턴으로 하고, 라인 차이는
#   경고로만 보고한다(원본에 주석 몇 줄이 추가돼도 실패시키지 않기 위함).
# ---------------------------------------------------------------------------
FUNCTIONS = [
    # L1 -- 전부 non-static. static 이 아닌데도 export 가 없어 호출 불가였다.
    ("GetMyDllDirectory",          "L1",   57, False, False, "std::wstring"),
    ("WideToMultiByte",            "L1",   68, False, False, "std::string"),
    ("WriteStyleUSLog",            "L1",   81, False, False, "void"),
    # WriteStyleUSLogW 는 호출처가 없다. LOG_INFO 매크로는 StyleUSLogWriter 를
    # 거쳐 WriteStyleUSLog(narrow) 를 부르고, wstring 은 operator<< 안에서
    # WideToMultiByte 로 변환된다. 이 함수만 홀로 떠 있다.
    ("WriteStyleUSLogW",           "L1",  153, False, True,  "void"),
    ("CombinePath",                "L1",  198, False, False, "std::string"),
    ("SimpleCombine",              "L1",  211, False, False, "std::string"),
    ("ParseXYFromFileName",        "L1",  226, False, False, "bool"),
    ("SearchFileInDir",            "L1",  250, False, False, "std::string"),
    ("FindRawFileAndParseSize",    "L1",  295, False, False, "std::string"),
    ("FindDicomFile",              "L1", 1703, False, False, "std::string"),
    # L2
    ("ReadU16",                    "L2",  423, True,  False, "uint16_t"),
    ("ReadU32",                    "L2",  429, True,  False, "uint32_t"),
    ("ReadString",                 "L2",  439, True,  False, "std::string"),
    ("IsLongFormVR",               "L2",  447, True,  False, "bool"),
    ("ParseElements",              "L2",  475, True,  False, "bool"),
    ("LoadDicomImage",             "L2",  566, True,  False, "bool"),
    # L3
    ("SaturateCastU8",             "L3",  408, True,  False, "uint8_t"),
    ("CastToUint8Truncate",        "L3",  416, True,  True,  "uint8_t"),
    ("Lanczos4Weights",            "L3",  706, True,  False, "void"),
    ("ResizeLanczos4",             "L3",  728, True,  False, "bool"),
    ("ToGray",                     "L3",  799, True,  False, "void"),
    ("ThresholdBinary",            "L3",  821, True,  False, "void"),
    ("MorphRectBinary",            "L3",  832, True,  False, "void"),
    ("MorphCloseBinary",           "L3",  867, True,  False, "void"),
    ("SplineFilter1D",             "L3", 1273, True,  False, "void"),
    ("SplineFilter2D",             "L3", 1305, True,  False, "bool"),
    ("SampleCubicSpline",          "L3", 1321, True,  False, "double"),
    ("SampleBilinear",             "L3", 1358, True,  False, "double"),
    # L4
    ("FindRobustSeed",             "L4",  875, True,  False, "bool"),
    ("FloodFillMask",              "L4",  908, True,  False, "void"),
    ("TraceOuterContour",          "L4",  941, True,  True,  "std::vector<PointI>"),
    ("FindHighestCoordinates",     "L4", 1012, True,  True,  "std::vector<PointI>"),
    ("CalculateAngleWithVertical", "L4", 1048, True,  True,  "bool"),
    ("FindRadius",                 "L4", 1163, True,  True,  "void"),
    ("SectorValid",                "L4", 1435, True,  False, "bool"),
    ("SectorIoU",                  "L4", 1400, True,  False, "double"),
    ("FitSectorOnce",              "L4", 1439, True,  False, "double"),
    ("FitSector",                  "L4", 1466, True,  False, "bool"),
    # L5
    ("AnalyzeDicom",               "L5", 1522, True,  False, "bool"),
    ("BuildPolarFrameF",           "L5", 1597, True,  False, "bool"),
    ("ToCvRawPixelsF",             "L5", 1682, True,  False, "void"),
    ("ToLqsRawPixelsF",            "L5", 1693, True,  False, "void"),
    # md 목록에서 누락되어 있던 43번째
    ("Aborted",                    "L4",  405, True,  False, "bool"),
]

# RunStyleUSInference() 안에 인라인으로 박힌 전처리 단계.
# 함수가 아니므로 export 로는 절대 열 수 없다 -> shim_stages.inc 가 등가 재현한다.
STAGES = [
    ("S1_PadCV",        2106, "CV 제로패딩 -> 606x1024",            "int w_idx = max_w / 2 - src_w / 2;"),
    ("S2_BuildCVHist",  2118, "CV 4단 피라미드 + 히스토그램",        "std::vector<float> cv_hist_data(4 * 256, 0.0f);"),
    ("S3_MakePreset",   2182, "body_preset 37차",                    "preset_data[4] = 1.0f;"),
    ("S4_PostCV",       2217, "ReLU + range 역정규화",               "pred_params[i] = std::max(raw_out_params[i], 0.0f)"),
    ("S5_RotateLQS",    2237, "LQS 90도 시계방향 회전",              "std::vector<float> rotated_lqs(lqs_x * lqs_y, 0.0f);"),
    ("S6_LqsStats",     2254, "LQS mean/std",                        "float raw_mean = static_cast<float>(lqs_sum / (lqs_x * lqs_y));"),
    ("S7_PadLQS",       2272, "LQS 패딩 1024x512, /150",             "int pad_w_idx = pad_w / 2 - lqs_w / 2;"),
    ("S8_LqsMeta",      2288, "meta_info 4차",                       "std::vector<float> lqs_meta_data = {"),
    ("S9_LqsHist",      2306, "LQS 히스토그램 /2048",                "/ 2048.0f;"),
    ("S10_PostLQS",     2336, "LQS 역정규화 (ReLU 없음)",            "lqs_preds[i] = raw_lqs_out[i] * (lqs_max[i] - lqs_min[i]) + lqs_min[i];"),
    ("S11_PackRSDMR",   2419, "RSDMR[5] 패킹",                       "RSDMR finalRsdmr[5] = {};"),
    ("S12_WriteIni",    2365, "ini 텍스트 생성",                     "iniFile << \"[BProbe]\\n\";"),
]

C1 = "\033[36m"
C2 = "\033[33m"
CR = "\033[31m"
CG = "\033[32m"
C0 = "\033[0m"


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def find_definition(lines: list[str], name: str) -> list[tuple[int, str, bool]]:
    """함수 '정의' 로 보이는 줄을 찾는다. 반환: [(1-based line, 줄내용, is_static)]"""
    # 정의는 컬럼 0 에서 시작한다(원본 전체가 그렇다). 호출부는 들여쓰기되어 있다.
    pat = re.compile(
        r"^(static\s+)?(?:inline\s+)?"          # static / inline
        r"[A-Za-z_][\w:<>,\s\*&]*?"             # 반환형
        r"\b" + re.escape(name) + r"\s*\("      # 이름 + 여는 괄호
    )
    out = []
    for i, ln in enumerate(lines):
        if not ln or ln[0].isspace():
            continue
        m = pat.match(ln)
        if m:
            out.append((i + 1, ln.rstrip(), bool(m.group(1))))
    return out


def verify_source(src: Path) -> tuple[int, list[str]]:
    text = src.read_text(encoding="utf-8", errors="replace")
    lines = text.split("\n")
    problems: list[str] = []
    warnings: list[str] = []

    print(f"{C1}[1] 함수 인벤토리 검사 ({len(FUNCTIONS)}개){C0}")
    for name, layer, want_line, want_static, dead, ret in FUNCTIONS:
        hits = find_definition(lines, name)
        if not hits:
            problems.append(f"정의를 찾을 수 없음: {name} ({layer}, 기대 라인 {want_line})")
            print(f"  {CR}X{C0} {name:<28} 정의 없음")
            continue
        line, content, is_static = hits[0]
        tag = f"{CG}OK{C0}"
        note = ""
        if is_static != want_static:
            warnings.append(
                f"{name}: static 여부가 다르다 (기대 {want_static}, 실제 {is_static})")
            tag = f"{C2}!!{C0}"
            note = f" static={is_static}(기대 {want_static})"
        if abs(line - want_line) > 3:
            warnings.append(f"{name}: 라인 이동 {want_line} -> {line}")
            if tag == f"{CG}OK{C0}":
                tag = f"{C2}~~{C0}"
            note += f" 라인 {want_line}->{line}"
        dead_mark = f" {C2}[dead code]{C0}" if dead else ""
        print(f"  {tag} {name:<28} L{line:<5} {layer}{dead_mark}{note}")

    # ---- 호출 그래프 기반 dead code 판정 ----------------------------------
    #  "호출처가 0곳인가" 만 보면 부족하다. TraceOuterContour 는 호출처가 1곳
    #  있지만 그 호출자(CalculateAngleWithVertical)가 이미 dead 라서 전이적으로
    #  도달 불가다. 그래서 export 함수에서 시작하는 도달성 분석을 한다.
    #
    #  주석(// 및 /* */)을 먼저 제거한다. 원본 328~333행의 "원본 -> 이식 대응표"
    #  주석에 함수 이름이 나열되어 있어 지우지 않으면 호출로 오인된다.
    print(f"\n{C1}[2] 호출 그래프 도달성 분석 (dead code 판정){C0}")
    code = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    code = re.sub(r"//[^\n]*", "", code)
    clines = code.split("\n")

    # 파일 최상위 구성요소(함수/클래스)의 시작 라인을 전부 모은다.
    top_re = re.compile(
        r"^(?:STYLEUS_API\s+)?(?:static\s+)?(?:inline\s+)?"
        r"(?:[A-Za-z_][\w:<>,\s\*&]*?\s|\s*)"
        r"\b([A-Za-z_]\w*)\s*\("
    )
    class_re = re.compile(r"^class\s+([A-Za-z_]\w*)")
    tops: list[tuple[int, str]] = []
    for i, ln in enumerate(clines):
        if not ln or ln[0].isspace():
            continue
        m = class_re.match(ln)
        if m:
            tops.append((i + 1, m.group(1)))
            continue
        m = top_re.match(ln)
        if m and m.group(1) not in ("if", "for", "while", "switch", "return", "sizeof"):
            tops.append((i + 1, m.group(1)))
    tops.sort()

    def enclosing(line_no: int) -> str:
        lo, hi, best = 0, len(tops) - 1, "<file-scope>"
        while lo <= hi:
            mid = (lo + hi) // 2
            if tops[mid][0] <= line_no:
                best = tops[mid][1]
                lo = mid + 1
            else:
                hi = mid - 1
        return best

    target_names = {f[0] for f in FUNCTIONS}
    callers: dict[str, set[str]] = {n: set() for n in target_names}
    for name in target_names:
        for m in re.finditer(r"\b" + re.escape(name) + r"\s*\(", code):
            ln = code[:m.start()].count("\n") + 1
            enc = enclosing(ln)
            if enc == name:       # 자기 정의 줄 또는 재귀
                continue
            callers[name].add(enc)

    # export 함수 및 43개 밖의 문맥(StyleUSLogWriter 등)에서 불리면 살아있다.
    live: set[str] = set()
    frontier = [n for n in target_names
                if any(c not in target_names for c in callers[n])]
    while frontier:
        n = frontier.pop()
        if n in live:
            continue
        live.add(n)
        for other in target_names:
            if other not in live and n in callers[other]:
                frontier.append(other)

    for name, layer, _, _, dead, _ in FUNCTIONS:
        is_live = name in live
        srcs = sorted(callers[name]) or ["(없음)"]
        if dead and is_live:
            warnings.append(f"{name}: dead 로 표시했으나 도달 가능하다 (호출자 {srcs})")
            print(f"  {C2}!!{C0} {name:<28} dead 표시인데 도달 가능  <- {', '.join(srcs)}")
        elif (not dead) and not is_live:
            warnings.append(f"{name}: 도달 불가 -> dead code 로 승격해야 한다")
            print(f"  {C2}!!{C0} {name:<28} 도달 불가 -> dead 후보  <- {', '.join(srcs)}")
        elif dead:
            kind = "호출처 없음" if srcs == ["(없음)"] else f"dead 함수에서만 호출: {', '.join(srcs)}"
            print(f"  {CG}OK{C0} {name:<28} dead 확정 ({kind})")
    print(f"  -- 도달 가능 {len(live)}개 / 전체 {len(target_names)}개, "
          f"dead {len(target_names) - len(live)}개")

    print(f"\n{C1}[3] 인라인 스테이지 S1~S12 앵커 검사{C0}")
    for sid, want_line, desc, anchor in STAGES:
        idx = text.find(anchor)
        if idx < 0:
            problems.append(f"{sid}: 앵커 코드를 찾을 수 없음 -> shim_stages.inc 재현이 낡았다")
            print(f"  {CR}X{C0} {sid:<16} 앵커 없음: {anchor[:50]}")
            continue
        line = text[:idx].count("\n") + 1
        tag = f"{CG}OK{C0}"
        note = ""
        if abs(line - want_line) > 3:
            warnings.append(f"{sid}: 라인 이동 {want_line} -> {line}")
            tag = f"{C2}~~{C0}"
            note = f" 라인 {want_line}->{line}"
        print(f"  {tag} {sid:<16} L{line:<5} {desc}{note}")

    print(f"\n{C1}[4] 계약 상수 검사{C0}")
    checks = [
        ("kCvSampleSize",  r"kCvSampleSize\s*=\s*(\d+)", "1008"),
        ("kCvScanline",    r"kCvScanline\s*=\s*(\d+)",   "360"),
        ("kLqsSampleSize", r"kLqsSampleSize\s*=\s*(\d+)", "1008"),
        ("kLqsScanline",   r"kLqsScanline\s*=\s*(\d+)",  "360"),
        ("kUpscaleFactor", r"kUpscaleFactor\s*=\s*([\d.]+)", "3.0"),
        ("kOpenKernel",    r"kOpenKernel\s*=\s*(\d+)",   "3"),
        ("kCloseKernel",   r"kCloseKernel\s*=\s*(\d+)",  "5"),
        ("kMinSectorIoU",  r"kMinSectorIoU\s*=\s*([\d.]+)", "0.90"),
        ("DUMMY_MODE",     r"STYLEUS_DUMMY_MODE\s+(\d+)", "0"),
    ]
    for label, pat, want in checks:
        m = re.search(pat, text)
        got = m.group(1) if m else None
        ok = got is not None and float(got) == float(want)
        print(f"  {CG+'OK'+C0 if ok else C2+'!!'+C0} {label:<18} = {got}  (기대 {want})")
        if not ok:
            warnings.append(f"상수 {label} 가 {got} 다 (기대 {want})")

    if warnings:
        print(f"\n{C2}경고 {len(warnings)}건{C0}")
        for w in warnings:
            print(f"  - {w}")
    return len(problems), problems


# ---------------------------------------------------------------------------
# static 제거본 (참고용 폴백)
# ---------------------------------------------------------------------------
# 네임스페이스 스코프의 '함수 정의' 에 붙은 static 만 지운다.
#   · 컬럼 0 에서 시작하는 줄만 대상 (지역 static 은 전부 들여쓰기되어 있다)
#   · 뒤에 '식별자 + (' 가 오는 경우만 (static const double kDirs[9][5] 같은
#     변수 선언은 제외)
#   · \bstatic\b 는 static_cast 에 매치되지 않는다 ('_' 는 단어 문자라 경계가 아님)
STRIP_RE = re.compile(
    r"^static\s+(?=(?:inline\s+)?[A-Za-z_][\w:<>,\s\*&]*?\b[A-Za-z_]\w*\s*\()",
    re.MULTILINE,
)


def make_stripped(src_text: str) -> tuple[str, int]:
    out, n = STRIP_RE.subn("", src_text)
    return out, n


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".", help="워크스페이스 루트 (styleus.cpp 가 있는 곳)")
    ap.add_argument("--mode", choices=["unit", "strip", "both"], default="unit",
                    help="unit=유닛빌드용 사본(기본) / strip=static 제거본도 생성")
    ap.add_argument("--verify-only", action="store_true", help="복사 없이 검사만")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    src = root / "styleus.cpp"
    if not src.exists():
        print(f"{CR}styleus.cpp 를 찾을 수 없다: {src}{C0}")
        return 2

    print(f"{C1}=== StyleUS 시뮬레이터 소스 준비 ==={C0}")
    print(f"루트     : {root}")
    print(f"원본     : {src.name}  ({src.stat().st_size:,} bytes)")
    print(f"SHA-256  : {sha256(src)}\n")

    nfail, problems = verify_source(src)

    if args.verify_only:
        print()
        if nfail:
            print(f"{CR}치명적 문제 {nfail}건{C0}")
            for p in problems:
                print(f"  - {p}")
            return 1
        print(f"{CG}검사 통과{C0}")
        return 0

    # ---- 스테이징 ----------------------------------------------------------
    print(f"\n{C1}[5] build_src/ 스테이징{C0}")
    dst_dir = root / "build_src"
    (dst_dir / "SDMR").mkdir(parents=True, exist_ok=True)

    dst_cpp = dst_dir / "styleus.cpp"
    shutil.copy2(src, dst_cpp)
    if sha256(dst_cpp) != sha256(src):
        print(f"  {CR}X{C0} 복사본 해시 불일치")
        return 1
    print(f"  {CG}OK{C0} styleus.cpp        (바이트 동일, SHA-256 일치)")

    inc = root / "shim" / "include"
    pairs = [
        (inc / "styleus.h",          dst_dir / "styleus.h"),
        (inc / "SDMR" / "DllMain.h", dst_dir / "SDMR" / "DllMain.h"),
        (inc / "SDMR" / "CommonDef.h", dst_dir / "SDMR" / "CommonDef.h"),
        (inc / "SDMR" / "SLibUtils.h", dst_dir / "SDMR" / "SLibUtils.h"),
    ]
    for s, d in pairs:
        if not s.exists():
            print(f"  {CR}X{C0} {s} 없음")
            return 1
        shutil.copy2(s, d)
        print(f"  {CG}OK{C0} {d.relative_to(root)}")

    # 손상된 원본 헤더가 그대로면 경고 (복사본을 쓰므로 빌드는 되지만 알려준다)
    for orig, label in [(root / "styleus.h", "styleus.h"),
                        (root / "SDMR" / "DllMain.h", "SDMR/DllMain.h")]:
        if orig.exists():
            t = orig.read_text(encoding="utf-8", errors="replace")
            broken = len(re.findall(
                r"#(?:ifdef|ifndef|define|include|endif|elif|pragma)[A-Za-z_\"]"
                r"|typedefstruct|externC", t))
            if broken:
                print(f"  {C2}!!{C0} 원본 {label} 에 공백 소실 {broken}곳 -- "
                      f"복구본을 대신 사용한다. 사내 원본 재확보 권장")

    # ---- onnxruntime.lib ---------------------------------------------------
    print(f"\n{C1}[6] onnxruntime 배치{C0}")
    ort_lib = root / "onnxruntime" / "lib" / "onnxruntime.lib"
    if ort_lib.exists():
        (root / "lib").mkdir(exist_ok=True)
        shutil.copy2(ort_lib, root / "lib" / "onnxruntime.lib")
        print(f"  {CG}OK{C0} lib/onnxruntime.lib")
        print(f"     styleus.cpp:39 의 #pragma comment(lib, \"../lib/onnxruntime.lib\") 대응.")
        print(f"     빌드 디렉터리가 루트 바로 아래(build/)일 때 이 상대경로가 맞는다.")
    else:
        print(f"  {C2}!!{C0} {ort_lib} 없음 -- 링크 단계에서 LNK1104 가 날 수 있다")

    ort_dll = root / "onnxruntime" / "lib" / "onnxruntime.dll"
    if ort_dll.exists():
        print(f"  {CG}OK{C0} onnxruntime.dll 확인 (실행 시 exe 옆에 복사되어야 한다)")

    # ---- static 제거본 (선택) ---------------------------------------------
    if args.mode in ("strip", "both"):
        print(f"\n{C1}[7] static 제거본 생성 (참고용){C0}")
        text = src.read_text(encoding="utf-8", errors="replace")
        stripped, n = make_stripped(text)
        # 안전성 확인: 지역 static / static_cast 가 살아있어야 한다
        must_keep = [
            "static std::string cachedLogFilePath",
            "static const double cs[8][2]",
            "static const double kStarts[5]",
            "static_cast<size_t>",
            "static const int dx8[8]",
        ]
        bad = [k for k in must_keep if k not in stripped]
        outp = dst_dir / "styleus_nostatic.cpp"
        outp.write_text(stripped, encoding="utf-8")
        print(f"  제거한 static: {n}개 -> {outp.relative_to(root)}")
        for k in must_keep:
            print(f"  {CG+'OK'+C0 if k in stripped else CR+'X'+C0} 보존 확인: {k}")
        if bad:
            print(f"  {CR}지역 static/static_cast 가 훼손됐다. 이 파일을 쓰면 안 된다.{C0}")
        print(f"  {C2}참고{C0}: 이 파일은 기본 빌드 경로가 아니다. static 을 떼도 "
              f"export 는 생기지 않으므로 그 자체로는 호출할 수 없다.")

    # ---- 매니페스트 --------------------------------------------------------
    print(f"\n{C1}[8] functions.json 생성{C0}")
    manifest = {
        "source": str(src),
        "source_sha256": sha256(src),
        "function_count": len(FUNCTIONS),
        "stage_count": len(STAGES),
        "functions": [
            {"name": n, "layer": l, "src_line": ln, "static": st,
             "dead_code": dd, "returns": rt}
            for n, l, ln, st, dd, rt in FUNCTIONS
        ],
        "stages": [
            {"id": s, "src_line": ln, "desc": d} for s, ln, d, _ in STAGES
        ],
        "notes": [
            "L1 함수 10개는 원본에서 이미 non-static 이지만 export 가 없어 호출 불가였다.",
            "dead_code=true 인 5개는 원본 파이프라인에서 호출되지 않는다.",
            "S1~S12 는 함수가 아니라 RunStyleUSInference() 내부 인라인 코드다.",
        ],
    }
    mf = root / "build_src" / "functions.json"
    mf.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  {CG}OK{C0} {mf.relative_to(root)}")

    print()
    if nfail:
        print(f"{CR}치명적 문제 {nfail}건 -- 빌드 전에 해결할 것{C0}")
        for p in problems:
            print(f"  - {p}")
        return 1
    print(f"{CG}준비 완료.{C0}  다음:  build.bat Debug   "
          f"(또는 cmake -S . -B build && cmake --build build --config Debug)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
