#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest.py -- 빌드 직후 CLI 자체 검증

DICOM / RAW 자산이 하나도 없어도 돌아가는 항목만 골라서 검사한다.
목적은 두 가지다.

  1. DLL 이 제대로 export 되고 exe 가 매니페스트를 읽는지 확인한다.
  2. md 문서의 계약(§4.1 sizeof(RSDMR)=256, §4.2 고정상수 산식, 부록 A range 표)이
     실제 빌드 결과와 일치하는지 못 박는다.

자산이 있으면 --dicom 으로 경로를 주면 마스크 체인까지 검사한다.

사용
    python tools/selftest.py --exe build/Debug/styleus_sim.exe
    python tools/selftest.py --exe ... --dicom C:\\dump\\...\\style_01.dcm
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CR, CG, C2, C0 = "\033[31m", "\033[32m", "\033[33m", "\033[0m"

PASS = 0
FAIL = 0
SKIP = 0


def run(exe: str, args: list[str], extra: list[str]) -> tuple[int, str]:
    cmd = [exe, "--cli"] + args + extra
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def jrun(exe: str, args: list[str], extra: list[str]) -> tuple[int, dict | None, str]:
    rc, out = run(exe, args + ["--raw"], extra)
    try:
        # --raw 는 JSON 한 줄을 그대로 낸다. 앞뒤 잡소리를 제거한다.
        s = out[out.index("{"): out.rindex("}") + 1]
        return rc, json.loads(s), out
    except Exception:
        return rc, None, out


def check(label: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  {CG}PASS{C0} {label}")
    else:
        FAIL += 1
        print(f"  {CR}FAIL{C0} {label}" + (f"\n         {detail}" if detail else ""))


def skip(label: str, why: str) -> None:
    global SKIP
    SKIP += 1
    print(f"  {C2}SKIP{C0} {label}  ({why})")


def deep(d, *keys, default=None):
    cur = d
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        elif isinstance(cur, list) and isinstance(k, int) and k < len(cur):
            cur = cur[k]
        else:
            return default
    return cur


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--dll", default="")
    ap.add_argument("--out", default="sim_out/selftest")
    ap.add_argument("--dicom", default="", help="있으면 마스크 체인까지 검사")
    ap.add_argument("--cv-raw", default="", help="*_CV.raw 경로")
    ap.add_argument("--cv-size", default="", help="예: 528x177")
    a = ap.parse_args()

    exe = str(Path(a.exe).resolve())
    if not Path(exe).exists():
        print(f"{CR}exe 를 찾을 수 없다: {exe}{C0}")
        return 2
    extra = ["--out", a.out]
    if a.dll:
        extra += ["--dll", str(Path(a.dll).resolve())]

    print(f"exe: {exe}\nout: {a.out}\n")

    # ---- 0. 로드 / 매니페스트 ---------------------------------------------
    print("[0] 로드 & 매니페스트")
    rc, out = run(exe, ["info"], extra)
    check("DLL 로드 + SIM_BuildInfo", rc == 0 and "abi=" in out, out[:400])
    if rc != 0:
        print(f"\n{CR}DLL 을 못 붙였다. 나머지 검사를 건너뛴다.{C0}\n{out[:800]}")
        return 1
    print("       " + out.strip().splitlines()[0][:150])

    check("sizeof(RSDMR) == 256  (md §4.1 / 발견사항 #5)",
          "sizeof(RSDMR)=256" in out, out[:300])
    check("rsdmr 파일 크기 1288 bytes", "rsdmr_file_bytes=1288" in out)
    check("kMinSectorIoU 0.9", "kMinSectorIoU=0.9" in out)
    check("STYLEUS_DUMMY_MODE=0 (실제 추론 경로)", "STYLEUS_DUMMY_MODE=0" in out)

    rc, out = run(exe, ["list"], extra)
    check("함수 목록 출력", rc == 0 and "L1" in out and "S12_WriteIni" in out)
    check("dead code 6개 표기", out.count("[DEAD]") == 6,
          f"실제 {out.count('[DEAD]')}개")

    check("Tier C 주의사항이 목록에 노출됨 (순서/배타경로/좌표계)",
          "확대 전 원본 해상도" in out and "배타적 경로" in out and
          "source px 좌표계" in out)

    rc, out = run(exe, ["chains"], extra)
    check("체인 목록 출력", rc == 0 and "mask" in out and "post_and_pack" in out)

    # ---- 1. Tier A: 자산 없이 단독 실행 -----------------------------------
    print("\n[1] Tier A -- 자산 없이 단독 실행")

    rc, j, raw = jrun(exe, ["call", "IsLongFormVR"], extra)
    check("IsLongFormVR: long-form VR 정확히 11종",
          deep(j, "long_form_count") == 11 and deep(j, "match_expected") is True,
          f"count={deep(j, 'long_form_count')}")

    rc, j, raw = jrun(exe, ["call", "Lanczos4Weights",
                            "values=0,0.25,0.5,0.75,1.0"], extra)
    sweeps = deep(j, "sweep", default=[])
    check("Lanczos4Weights: 가중치 합 = 1.0 (전 구간)",
          bool(sweeps) and all(s.get("sum_is_one") for s in sweeps),
          json.dumps([s.get("sum") for s in sweeps], ensure_ascii=False))

    rc, j, raw = jrun(exe, ["call", "SaturateCastU8"], extra)
    sw = deep(j, "sweep", default=[])
    neg = next((s for s in sw if s.get("input") == -1.0), None)
    check("SaturateCastU8(-1) == 0 (포화)", neg and neg.get("SaturateCastU8") == 0)
    check("CastToUint8Truncate(-1) != 0 (래핑, 두 함수 차이 확인)",
          neg and neg.get("CastToUint8Truncate") != 0,
          f"{neg}")

    rc, j, raw = jrun(exe, ["call", "SectorValid", "ri=0.5"], extra)
    check("SectorValid: ri<=1.0 이면 false",
          deep(j, "return") is False and deep(j, "conditions", "ri_gt_1") is False)

    rc, j, raw = jrun(exe, ["call", "ParseXYFromFileName",
                            "filename=style_01_x528_y177_CV.raw"], extra)
    check("ParseXYFromFileName: x=528, y=177",
          deep(j, "outX") == 528 and deep(j, "outY") == 177,
          f"{deep(j,'outX')},{deep(j,'outY')}")

    rc, j, raw = jrun(exe, ["call", "ParseXYFromFileName",
                            "filename=style_x1_y2_x528_y177_CV.raw"], extra)
    check("ParseXYFromFileName: 이름에 _x/_y 중복 시 경고 (발견사항 #9)",
          "warning" in (j or {}))

    rc, j, raw = jrun(exe, ["call", "ReadU16", "hex=01 02", "off=0"], extra)
    check("ReadU16 LE=0x0201 / BE=0x0102",
          deep(j, "little_endian") == 0x0201 and deep(j, "big_endian") == 0x0102)

    rc, j, raw = jrun(exe, ["call", "ReadU16", "hex=01", "off=0"], extra)
    check("ReadU16 경계 초과 시 0 반환 (방어 확인)",
          deep(j, "little_endian") == 0)

    rc, j, raw = jrun(exe, ["call", "SimpleCombine", "dir=C:\\a", "file=b.ini"], extra)
    check("SimpleCombine 결합", deep(j, "return") == "C:\\a\\b.ini",
          str(deep(j, "return")))

    rc, j, raw = jrun(exe, ["call", "S3_MakePreset"], extra)
    check("S3 body_preset: index 4 하드코딩 (발견사항 #11)",
          deep(j, "hot_index") == 4 and deep(j, "depends_on_styleName") is False)

    # ---- 2. 후처리 / 패킹 -- ONNX 없이 검증 -------------------------------
    print("\n[2] 후처리 & 패킹 (ONNX 모델 불필요)")

    raw37 = ",".join(["0.5"] * 37)
    rc, j, _ = jrun(exe, ["call", "S4_PostCV", f"raw37={raw37}"], extra)
    params = deep(j, "params", default=[])
    check("S4: 37개 전부 range 안에 들어옴 (raw=0.5 중간값)",
          len(params) == 37 and all(p.get("in_range") for p in params))
    check("S4: idx0 = (0.0022-0.0016)*0.5+0.0016 = 0.0019",
          abs(deep(j, "params", 0, "value", default=0) - 0.0019) < 1e-6,
          str(deep(j, "params", 0, "value")))

    neg37 = ",".join(["-1.0"] * 37)
    rc, j, _ = jrun(exe, ["call", "S4_PostCV", f"raw37={neg37}"], extra)
    check("S4: 음수 입력 37개 전부 ReLU 클램프 (CV 는 ReLU 있음)",
          deep(j, "relu_clamped_count") == 37)

    rc, j, _ = jrun(exe, ["call", "S10_PostLQS", "raw7=-1,-1,-1,-1,-1,-1,-1"], extra)
    check("S10: ReLU 미적용 (CV 와 비대칭, 발견사항 #10)",
          deep(j, "relu_applied") is False)
    p0 = deep(j, "params", 0, "value", default=None)
    check("S10: raw=-1 이면 lqs_min 아래로 내려감 (35-60=-25)",
          p0 is not None and abs(p0 - (-25.0)) < 1e-4, str(p0))

    pred37 = ",".join(["100.5"] * 37)
    rc, j, _ = jrun(exe, ["call", "S11_PackRSDMR", f"pred37={pred37}"], extra)
    check("S11: sizeof(RSDMR)=256, 파일 1288 bytes",
          deep(j, "sizeof_RSDMR") == 256 and deep(j, "file_bytes") == 1288)
    check("S11: 프리셋 5개가 전부 동일 (md §4.1)",
          deep(j, "all_presets_identical") is True)
    check("S11: iLapShrinkage 산식 검산 일치",
          deep(j, "packed_constants", "iLapShrinkage_matches") is True)
    check("S11: iFeatureAmplitude 산식 검산 일치",
          deep(j, "packed_constants", "iFeatureAmplitude_matches") is True)
    check("S11: int 캐스팅 절삭 손실 0.5 검출",
          len(deep(j, "int_cast_truncation", default=[])) > 0)

    # 발견사항 #6 -- 지수 표기
    rc, j, _ = jrun(exe, ["call", "S12_WriteIni",
                          "lqs7=50,40,9,45,-15,0.0000123,0.0000456"], extra)
    check("S12: 지수 표기 발생 검출 (발견사항 #6 확정)",
          deep(j, "FINDING_6_CONFIRMED") is True,
          json.dumps(deep(j, "ai_values", default=[]), ensure_ascii=False)[:300])
    check("S12: 키 34개",
          deep(j, "key_count") == 34, str(deep(j, "key_count")))

    rc, j, _ = jrun(exe, ["call", "S12_WriteIni", "lqs7=50,40,9,45,-15,0.05,0.02"], extra)
    check("S12: 평범한 값에서는 지수 표기 없음",
          deep(j, "FINDING_6_CONFIRMED") is False)

    # 체인
    rc, j, _ = jrun(exe, ["chain", "post_and_pack",
                          f"raw37={raw37}", "raw7=0.5,0.5,0.5,0.5,0.5,0.5,0.5"], extra)
    check("chain post_and_pack: 4단계 전부 성공",
          deep(j, "ok") is True and deep(j, "steps_executed") == 4,
          f"executed={deep(j,'steps_executed')}")

    # ---- 3. 슬롯 / 취소 플래그 --------------------------------------------
    print("\n[3] 슬롯 & 취소 플래그")

    rc, j, _ = jrun(exe, ["call", "Aborted", "set=1"], extra)
    check("Aborted: g_bForceExit 세팅 반영", deep(j, "Aborted") is True)
    rc, j, _ = jrun(exe, ["call", "Aborted", "set=0"], extra)
    check("Aborted: 해제 반영", deep(j, "Aborted") is False)

    rc, j, _ = jrun(exe, ["call", "SplineFilter1D",
                          "values=0,10,40,90,160,90,40,10,0"], extra)
    check("SplineFilter1D: 계수 슬롯 생성", deep(j, "spline1d") is not None)

    rc, j, _ = jrun(exe, ["slots"], extra)
    check("슬롯 목록 조회", deep(j, "ok") is True)

    # 선행 슬롯 없이 호출하면 친절한 오류가 나와야 한다
    rc, j, _ = jrun(exe, ["call", "FitSector"], extra)
    check("선행 슬롯 없이 FitSector -> MISSING_IN + 힌트",
          deep(j, "ok") is False and "hint" in (j or {}),
          json.dumps(j, ensure_ascii=False)[:200] if j else "")

    # ---- 4. 자산이 있으면 체인까지 ----------------------------------------
    print("\n[4] 자산 기반 검사")
    if a.dicom and Path(a.dicom).exists():
        d = str(Path(a.dicom).resolve())
        rc, j, _ = jrun(exe, ["call", "LoadDicomImage", f"path={d}"], extra)
        check("LoadDicomImage 성공", deep(j, "return") is True,
              str(deep(j, "error")))

        rc, j, _ = jrun(exe, ["chain", "mask", f"path={d}"], extra)
        ok = deep(j, "ok") is True
        check("chain mask 전 단계 성공", ok,
              json.dumps(deep(j, "steps", default=[])[-1:], ensure_ascii=False)[:400])

        rc, ja, _ = jrun(exe, ["call", "AnalyzeDicom", f"path={d}"], extra)
        if ok and deep(ja, "return") is True:
            exp = deep(j, "expected_geom_from_sector", default={})
            got = deep(ja, "geom", default={})
            def close(k1, k2):
                v1, v2 = exp.get(k1), got.get(k2)
                return v1 is not None and v2 is not None and abs(v1 - v2) < 1e-6
            check("체인 재현 == AnalyzeDicom (apex/ri/ro 일치)",
                  close("apex_x", "apex") is not False and
                  abs(exp.get("maxInnerRad", -1) - got.get("maxInnerRad", -2)) < 1e-6 and
                  abs(exp.get("maxOuterRad", -1) - got.get("maxOuterRad", -2)) < 1e-6,
                  f"expected={exp} got={got}")
        else:
            skip("체인 재현 == AnalyzeDicom", "선행 단계 실패")

        rc, j, _ = jrun(exe, ["chain", "dicom_to_polar", f"path={d}"], extra)
        check("chain dicom_to_polar 성공", deep(j, "ok") is True)
    else:
        skip("DICOM 기반 체인 검사", "--dicom 미지정")

    if a.cv_raw and Path(a.cv_raw).exists() and a.cv_size:
        w, h = a.cv_size.lower().split("x")
        rc, j, _ = jrun(exe, ["load", "cv_raw", "raw_i16",
                              str(Path(a.cv_raw).resolve()),
                              f"width={w}", f"height={h}"], extra)
        check("RAW(int16) 슬롯 적재", deep(j, "ok") is True)
        rc, j, _ = jrun(exe, ["chain", "cv_tensors"], extra)
        check("chain cv_tensors 성공", deep(j, "ok") is True)
        st = deep(j, "steps", default=[])
        s1 = next((s for s in st if s.get("id") == "S1_PadCV"), {})
        oob = s1.get("out_of_bounds_writes")
        if oob is not None:
            print(f"       S1 경계 이탈 쓰기: {oob}회 "
                  f"(0 이면 이 입력 크기에서는 안전, >0 이면 발견사항 #1 확정)")
    else:
        skip("RAW 기반 CV 텐서 검사", "--cv-raw / --cv-size 미지정")

    # ---- 요약 --------------------------------------------------------------
    print(f"\n{'='*60}")
    print(f"  PASS {PASS}   FAIL {FAIL}   SKIP {SKIP}")
    print(f"{'='*60}")
    if FAIL:
        print(f"{CR}실패 항목이 있다. 위 FAIL 을 확인하라.{C0}")
    else:
        print(f"{CG}전부 통과.{C0}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
