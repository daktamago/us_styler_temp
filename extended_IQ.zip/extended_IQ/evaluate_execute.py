import torch
import joblib
import os

from models import SiameseStyleRegressor_Base, SiameseStyleRegressor_MultiHead
from data_processing import load_scale_and_group_data
from evaluator import evaluate_model

def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}\n")
    
    # 1. 파일 경로 설정
    TEST_FILE = "IQ_Style_Test.xlsx"
    REF_FILE = "example_minmax_ref.xlsx"
    TRAIN_FILE = "IQ_Style_Train.xlsx" # 그룹핑 정보를 다시 가져오기 위해 활용
    
    # 2. 파라미터 그룹핑 정보 획득 (가짜로 로드하여 인덱스와 컬럼 이름만 획득)
    # *주의: 실제 데이터는 TEST_FILE에서 다시 불러오므로 여기서는 차원 정보만 사용합니다.
    _, _, _, _, _, _, iq_groups, groups, style_cols, total_iq_dim, total_style_dim = \
        load_scale_and_group_data(TRAIN_FILE, test_portion=0.01, random_state=42, iq_dim=60)
        
    all_iq_indices = list(range(total_iq_dim))
    all_style_indices = list(range(total_style_dim))
    all_style_names = style_cols

    # =======================================================
    # [Type 1] 전체 통합 모델 평가 예시
    # =======================================================
    model_path_t1 = 'model_Type1_Full.pth'
    if os.path.exists(model_path_t1):
        # 모델 구조 생성 및 가중치 로드
        model_t1 = SiameseStyleRegressor_Base(input_dim=total_iq_dim, output_dim=total_style_dim).to(device)
        model_t1.load_state_dict(torch.load(model_path_t1, map_location=device))
        
        # 스케일러 로드 (이 스케일러는 입력 60차원에 맞춰져 있음)
        scaler_X_t1 = joblib.load('scaler_x.pkl') # Type1 학습 시 저장한 스케일러 파일명과 맞춰주세요
        
        evaluate_model(
            model=model_t1, 
            scaler_X=scaler_X_t1, 
            test_file_path=TEST_FILE, 
            ref_file_path=REF_FILE, 
            iq_indices=all_iq_indices, 
            style_indices=all_style_indices, 
            style_names=all_style_names, 
            output_file_path="eval_result_Type1_Full.xlsx", 
            restore=1, delta=1.0, device=device
        )


    # =======================================================
    # [Type 3] Style 개별 모델 평가 예시 (Lv1 모델을 평가한다고 가정)
    # =======================================================
    lv_target = 'Lv1'
    model_path_t3 = f'model_Type3_Style_{lv_target}.pth'
    
    if os.path.exists(model_path_t3):
        # 해당 Level의 Style 인덱스와 이름 추출
        style_names_lv = groups.get(lv_target, [])
        style_indices_lv = [list(style_cols).index(c) for c in style_names_lv]
        
        # 모델 생성 (출력 차원이 해당 Lv의 파라미터 개수로 맞춰짐)
        model_t3 = SiameseStyleRegressor_Base(input_dim=total_iq_dim, output_dim=len(style_indices_lv)).to(device)
        model_t3.load_state_dict(torch.load(model_path_t3, map_location=device))
        
        # Type 3도 입력은 전체 60차원이므로 Type 1과 같은 스케일러 사용 가능
        scaler_X_t3 = joblib.load('scaler_x.pkl') 
        
        evaluate_model(
            model=model_t3, 
            scaler_X=scaler_X_t3, 
            test_file_path=TEST_FILE, 
            ref_file_path=REF_FILE, 
            iq_indices=all_iq_indices,        # 입력은 전체 IQ
            style_indices=style_indices_lv,   # 출력은 개별 Style
            style_names=style_names_lv, 
            output_file_path=f"eval_result_Type3_Style_{lv_target}.xlsx", 
            restore=1, delta=1.0, device=device
        )
        
    # (Type 2, 4, 5도 위와 같이 각각 학습 시 사용했던 iq_indices, style_indices 조합을 넣고 돌리시면 됩니다.)

if __name__ == "__main__":
    main()