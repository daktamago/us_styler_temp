import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from dataset import StyleDifferenceDataset  # 분리된 데이터셋 모듈 Import

def run_training_pipeline(model, X_train, y_train, X_val, y_val, 
                          batch_size=256, epochs=50, lr=1e-3, device='cuda'):
    
    print(f"[{model.__class__.__name__}] 모델 학습을 시작합니다...")
    
    # 1. DataLoader 구성
    train_loader = DataLoader(StyleDifferenceDataset(X_train, y_train), batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(StyleDifferenceDataset(X_val, y_val), batch_size=batch_size, shuffle=False)
    
    # 2. Loss & Optimizer
    criterion = nn.HuberLoss() 
    optimizer = optim.AdamW(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    # 3. Training Loop
    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        for curr_iq, tgt_iq, actual_diff in train_loader:
            curr_iq, tgt_iq, actual_diff = curr_iq.to(device), tgt_iq.to(device), actual_diff.to(device)
            
            optimizer.zero_grad()
            pred_diff = model(curr_iq, tgt_iq)
            loss = criterion(pred_diff, actual_diff)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
            
        scheduler.step()
        
        # 4. Validation Loop
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for curr_iq, tgt_iq, actual_diff in val_loader:
                curr_iq, tgt_iq, actual_diff = curr_iq.to(device), tgt_iq.to(device), actual_diff.to(device)
                pred_diff = model(curr_iq, tgt_iq)
                loss = criterion(pred_diff, actual_diff)
                val_loss += loss.item()
                
        # 로그 출력
        if (epoch + 1) % 10 == 0 or epoch == epochs - 1:
            avg_train = train_loss / len(train_loader)
            avg_val = val_loss / len(val_loader)
            print(f"   Epoch [{epoch+1}/{epochs}] Train Loss: {avg_train:.4f} | Val Loss: {avg_val:.4f}")
            
    print("학습 완료!\n")
    return model