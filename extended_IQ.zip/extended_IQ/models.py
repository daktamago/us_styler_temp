import torch
import torch.nn as nn

# [기본형 아키텍처] Type 1, 3, 4, 5 전용
class SiameseStyleRegressor_Base(nn.Module):
    def __init__(self, input_dim, output_dim, dropout_rate=0.2):
        super(SiameseStyleRegressor_Base, self).__init__()
        
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(p=dropout_rate),
            nn.Linear(128, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(p=dropout_rate),
            nn.Linear(256, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(p=dropout_rate)
        )
        
        self.regressor = nn.Sequential(
            nn.Linear(256, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(p=dropout_rate),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(p=dropout_rate),
            nn.Linear(128, output_dim) 
        )

    def forward(self, current_iq, target_iq):
        curr_feat = self.encoder(current_iq)
        tgt_feat = self.encoder(target_iq)
        feat_diff = tgt_feat - curr_feat
        return self.regressor(feat_diff)


# [멀티헤드 아키텍처] Type 2 전용
class SiameseStyleRegressor_MultiHead(nn.Module):
    def __init__(self, input_dim, head_dims, dropout_rate=0.2):
        super(SiameseStyleRegressor_MultiHead, self).__init__()
        
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(p=dropout_rate),
            nn.Linear(128, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(p=dropout_rate)
        )
        
        self.regressor_base = nn.Sequential(
            nn.Linear(256, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(p=dropout_rate)
        )
        
        # 각 Lv별 Head 동적 생성
        self.heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(256, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(p=dropout_rate),
                nn.Linear(128, out_dim)
            ) for out_dim in head_dims
        ])

    def forward(self, current_iq, target_iq):
        curr_feat = self.encoder(current_iq)
        tgt_feat = self.encoder(target_iq)
        feat_diff = tgt_feat - curr_feat
        
        base_out = self.regressor_base(feat_diff)
        head_outputs = [head(base_out) for head in self.heads]
        return torch.cat(head_outputs, dim=1)